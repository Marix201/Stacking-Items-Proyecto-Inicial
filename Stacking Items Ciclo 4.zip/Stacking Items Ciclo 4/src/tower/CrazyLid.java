package tower;

/**
 * Tapa crazy (loca): en lugar de colocarse sobre su taza compañera, se ubica en la BASE de la torre (posición 0 de la lista de ítems).
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo 4
 */
public class CrazyLid extends Lid {

    /**
     * Crea una tapa crazy.
     * @param cupNumber número de la taza asociada
     * @param color     color base de la tapa
     */
    public CrazyLid(int cupNumber, String color) {
        super(cupNumber, "magenta"); // siempre magenta para distinguirla
    }

    @Override
    public String getSubtype() { 
        return "crazy"; 
    }
}
