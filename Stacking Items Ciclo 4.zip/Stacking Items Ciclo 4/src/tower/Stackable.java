package tower;

/**
 * Interfaz que deben implementar todos los elementos apilables en la torre.
 * Define el contrato común de posición, visibilidad y comportamiento.
 *
 * @author Hernandez - Tovar
 * @version 2 - Ciclo 4
 */
public interface Stackable {

    /** 
     * Retorna la subcategoría del ítem: "cup" o "lid". 
     */
    String getType();

    /** 
     * Retorna el subtipo específico: "normal", "opener", "hierarchical", "fearful", "crazy", "sticky". 
     */
    String getSubtype();

    /** 
     * Retorna el número identificador del ítem. 
     */
    int getItemNumber();

    /** 
     * Altura lógica del ítem en cm.
     */
    int getHeight();

    /** 
     * Ancho visual en píxeles. 
     */
    int getWidthPixels();

    /** 
     * Altura visual en píxeles. 
     */
    int getHeightPixels();

    /**
     * Hace visible el ítem en el canvas. 
     */
    void makeVisible();

    /**
     * Hace invisible el ítem en el canvas. 
     */
    void makeInvisible();

    /**
     * Retorna true si el ítem está actualmente visible. 
     */
    boolean isVisible();

    /**
     * Mueve el ítem a la posición (x, y) en el canvas. 
     */
    void moveTo(int x, int y);

    /**
     * Marca el ítem como tapado o destapado (no-op para tapas).
     */
    default void setCovered(boolean covered) { /* no-op para Lid */ }

    /**
     * Retorna true si el ítem está marcado como tapado.
     */
    default boolean isCovered() { return false; }

    /**
     * Cambia el color visual del ítem (no-op para tapas). 
     */
    default void setColor(String color) { /* no-op para Lid */ }
}
