package tower;

/**
 * Tapa normal: se apila sin restricciones sobre cualquier elemento.
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo 4
 */
public class NormalLid extends Lid {

    /**
     * Crea una tapa normal.
     * @param cupNumber número de la taza asociada
     * @param color     color de la tapa
     */
    public NormalLid(int cupNumber, String color) {
        super(cupNumber, color);
    }

    @Override
    public String getSubtype() {
        return "normal"; 
    }
}
