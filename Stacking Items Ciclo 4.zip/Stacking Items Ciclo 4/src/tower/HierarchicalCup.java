package tower;

import shapes.Rectangle;

/**
 * Taza hierarchical: al entrar a la torre desplaza hacia arriba todos los objetos de menor tamaño que ella.
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo 4
 */
public class HierarchicalCup extends Cup {

    private boolean reachedBottom;

    // Franja visual de refuerzo
    private Rectangle stripe;
    private int stripeCurX, stripeCurY;

    private static final String STRIPE_COLOR = "black";
    private static final int    STRIPE_H     = 3;

    /**
     * Crea una taza hierarchical.
     * @param number número de la taza (&gt;= 1)
     * @param color  color base de la taza
     */
    public HierarchicalCup(int number, String color) {
        super(number, color);
        this.reachedBottom = false;
        buildStripe();
    }

    private void buildStripe() {
        stripe = new Rectangle();
        stripe.changeColor(STRIPE_COLOR);
        stripe.changeSize(STRIPE_H, getWidthPixels());
        stripe.moveHorizontal(-70);
        stripe.moveVertical(-15);
        stripeCurX = 0; stripeCurY = 0;
    }

    @Override
    public String getSubtype() { 
        return "hierarchical"; 
    }

    /**
     * Marca que esta taza alcanzó el fondo de la torre.
     * Una vez marcada, no puede quitarse.
     */
    public void setReachedBottom(boolean value) {
        this.reachedBottom = value;
    }

    /**
     * Retorna true si la taza ya alcanzó el fondo y no puede quitarse.
     */
    public boolean hasReachedBottom() {
        return reachedBottom;
    }

    @Override
    public void makeVisible() {
        super.makeVisible();
        stripe.makeVisible();
    }

    @Override
    public void makeInvisible() {
        super.makeInvisible();
        stripe.makeInvisible();
    }

    @Override
    public void moveTo(int x, int y) {
        super.moveTo(x, y);
        // Franja a mitad de la altura visual
        int stripeY = y + getHeightPixels() / 2;
        stripe.moveHorizontal(x - stripeCurX);
        stripe.moveVertical(stripeY - stripeCurY);
        stripeCurX = x; stripeCurY = stripeY;
    }
}
