package tower;

import javax.swing.JOptionPane;

/**
 * Pruebas de aceptación del Ciclo 4.
 * Cada prueba muestra visualmente el comportamiento y pregunta al usuario
 * si lo acepta.  Deben ejecutarse con el canvas visible.
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo 4
 */
public class TowerATest {

    private static final int PAUSE_MS = 1500;

    // ── Prueba de aceptación 1 ─────────────────────────────────────────────────

    /**
     * Prueba A1: Demostración de los subtipos de taza.
     */
    public static void acceptanceTest1() {
        JOptionPane.showMessageDialog(null,
            "PRUEBA DE ACEPTACIÓN 1\n" +
            "Demostración de subtipos de TAZA:\n\n" +
            "1. Torre inicial con cup4 > cup3 > cup2 > cup1 (normales)\n" +
            "2. Se agrega lid3 (tapa normal a cup3)\n" +
            "3. Se agrega cup1 OPENER → elimina tapas que le bloquean\n" +
            "4. Se agrega cup3 HIERARCHICAL → desplaza ítems menores\n\n" +
            "Presione OK para comenzar.",
            "Prueba A1 - Subtipos de Taza", JOptionPane.INFORMATION_MESSAGE);

        // Paso 1: torre base
        Tower tower = new Tower(500, 300);
        tower.pushCup("normal", 4);
        tower.pushCup("normal", 3);
        tower.pushCup("normal", 2);
        tower.pushCup("normal", 1);
        tower.makeVisible();
        pause();

        JOptionPane.showMessageDialog(null,
            "Torre inicial con 4 tazas normales.\nAltura: " + tower.height() + " cm.\n\nOK → agregar lid3.",
            "A1 - Paso 1", JOptionPane.INFORMATION_MESSAGE);

        // Paso 2: agregar tapa normal
        tower.pushLid("normal", 3);
        pause();
        JOptionPane.showMessageDialog(null,
            "Lid3 (normal) agregada encima de cup3.\n\nOK → agregar cup1 OPENER.",
            "A1 - Paso 2", JOptionPane.INFORMATION_MESSAGE);

        // Paso 3: opener elimina lid3 (ancho >= cup1)
        tower.pushCup("opener", 1);
        pause();
        JOptionPane.showMessageDialog(null,
            "Cup1 OPENER insertada.\nLas tapas con ancho >= cup1 fueron eliminadas.\n" +
            "Ítems actuales: " + tower.stackingItems().length + "\n\nOK → agregar cup3 HIERARCHICAL.",
            "A1 - Paso 3", JOptionPane.INFORMATION_MESSAGE);

        // Paso 4: hierarchical desplaza menores
        tower.pushCup("hierarchical", 3);
        pause();
        JOptionPane.showMessageDialog(null,
            "Cup3 HIERARCHICAL insertada.\nDesplazó los ítems más pequeños hacia arriba.\n" +
            "Altura final: " + tower.height() + " cm.",
            "A1 - Paso 4", JOptionPane.INFORMATION_MESSAGE);

        tower.exit();

        int resp = JOptionPane.showConfirmDialog(null,
            "¿El comportamiento mostrado es correcto?\n" +
            "- La taza opener eliminó las tapas bloqueantes.\n" +
            "- La taza hierarchical desplazó los ítems menores.",
            "A1 - ¿Acepta?", JOptionPane.YES_NO_OPTION);

        if (resp == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, "✓ Prueba A1 ACEPTADA.", "A1", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "✗ Prueba A1 RECHAZADA.", "A1", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Prueba de aceptación 2 ─────────────────────────────────────────────────

    /**
     * Prueba A2: Demostración de los subtipos de tapa.
     */
    public static void acceptanceTest2() {
        JOptionPane.showMessageDialog(null,
            "PRUEBA DE ACEPTACIÓN 2\n" +
            "Demostración de subtipos de TAPA:\n\n" +
            "- FEARFUL: no entra sin su taza; no sale si la está tapando\n" +
            "- CRAZY: se ubica en la base al entrar\n" +
            "- STICKY (propuesta): no puede quitarse una vez en la torre\n\n" +
            "Presione OK para comenzar.",
            "Prueba A2 - Subtipos de Tapa", JOptionPane.INFORMATION_MESSAGE);

        Tower tower = new Tower(500, 300);
        tower.pushCup("normal", 3);
        tower.pushCup("normal", 2);
        tower.pushCup("normal", 1);
        tower.makeVisible();
        pause();

        // Fearful sin taza → falla
        JOptionPane.showMessageDialog(null,
            "Intentando agregar lid2 FEARFUL sin que cup2 esté... (debería fallar)",
            "A2 - FearfulLid sin taza", JOptionPane.INFORMATION_MESSAGE);
        Tower towerTest = new Tower(500, 200);
        towerTest.pushLid("fearful", 2);
        boolean fearfulBlocked = !towerTest.ok();
        JOptionPane.showMessageDialog(null,
            fearfulBlocked ? "✓ FearfulLid bloqueada correctamente (cup2 no estaba)."
                           : "✗ FearfulLid debió ser bloqueada.",
            "A2 - FearfulLid", JOptionPane.INFORMATION_MESSAGE);

        // Fearful con taza → entra
        tower.pushLid("fearful", 1);
        pause();
        JOptionPane.showMessageDialog(null,
            "Lid1 FEARFUL agregada (cup1 está en la torre). ok=" + tower.ok() +
            "\n\nOK → agregar lid2 CRAZY.",
            "A2 - FearfulLid entra", JOptionPane.INFORMATION_MESSAGE);

        // Crazy va a la base
        tower.pushLid("crazy", 2);
        pause();
        String firstItem = tower.stackingItems()[0][0] + " " + tower.stackingItems()[0][2];
        JOptionPane.showMessageDialog(null,
            "Lid2 CRAZY agregada. Primer ítem en la lista: [" + firstItem + "]\n" +
            "(Debería ser 'lid crazy' porque va a la base)\n\nOK → agregar lid3 STICKY.",
            "A2 - CrazyLid", JOptionPane.INFORMATION_MESSAGE);

        // Sticky
        tower.pushLid("sticky", 3);
        pause();
        JOptionPane.showMessageDialog(null,
            "Lid3 STICKY agregada.\nIntentando quitarla con popLid...",
            "A2 - StickyLid", JOptionPane.INFORMATION_MESSAGE);
        int beforePop = tower.stackingItems().length;
        tower.popLid();
        int afterPop = tower.stackingItems().length;
        boolean stickyBlocked = !tower.ok() && beforePop == afterPop;
        JOptionPane.showMessageDialog(null,
            stickyBlocked ? "✓ StickyLid no pudo quitarse." : "✗ StickyLid debió bloquearse.",
            "A2 - StickyLid bloqueada", JOptionPane.INFORMATION_MESSAGE);

        // Fearful no sale mientras tape
        tower.cover();
        tower.popLid(); // intenta quitar fearful
        boolean fearfulStuck = !tower.ok();
        JOptionPane.showMessageDialog(null,
            fearfulStuck
                ? "✓ FearfulLid no salió mientras tapaba a cup1."
                : "✗ FearfulLid debió bloquearse al salir.",
            "A2 - FearfulLid bloqueada al salir", JOptionPane.INFORMATION_MESSAGE);

        tower.exit();

        int resp = JOptionPane.showConfirmDialog(null,
            "¿El comportamiento mostrado es correcto?\n" +
            "- FearfulLid bloqueada al entrar sin taza: " + (fearfulBlocked ? "SÍ" : "NO") + "\n" +
            "- CrazyLid fue a la base: " + ("lid crazy".equals(firstItem) ? "SÍ" : "NO") + "\n" +
            "- StickyLid no pudo quitarse: " + (stickyBlocked ? "SÍ" : "NO") + "\n" +
            "- FearfulLid no salió mientras tapaba: " + (fearfulStuck ? "SÍ" : "NO"),
            "A2 - ¿Acepta?", JOptionPane.YES_NO_OPTION);

        if (resp == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, "✓ Prueba A2 ACEPTADA.", "A2", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "✗ Prueba A2 RECHAZADA.", "A2", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void pause() {
        try { Thread.sleep(PAUSE_MS); } catch (InterruptedException e) { /* ignorar */ }
    }

    /** 
     * Ejecuta ambas pruebas de aceptación. 
     */
    public static void main(String[] args) {
        acceptanceTest1();
        acceptanceTest2();
    }
}
