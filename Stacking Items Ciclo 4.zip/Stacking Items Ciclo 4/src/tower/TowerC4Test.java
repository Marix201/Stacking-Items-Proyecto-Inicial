package tower;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas de unidad para el Ciclo 4.
 * Cubre los nuevos subtipos de taza y tapa, así como los métodos heredados.
 *
 * @author Hernandez - Tovar
 * @version 2 - Ciclo 4
 */
public class TowerC4Test {

    private Tower tower;

    @BeforeEach
    public void setUp() {
        tower = new Tower(500, 200);
    }

    // ── NormalCup ──────────────────────────────────────────────────────────────

    @Test
    public void normalCupShouldHaveCorrectSubtype() {
        tower.pushCup("normal", 1);
        assertEquals("normal", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void pushCupDefaultShouldBeNormal() {
        tower.pushCup(1);
        assertEquals("normal", tower.stackingItems()[0][2]);
    }

    // ── OpenerCup ─────────────────────────────────────────────────────────────

    @Test
    public void openerCupShouldHaveCorrectSubtype() {
        tower.pushCup("opener", 2);
        assertEquals("opener", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void openerCupShouldRemoveLidsBlockingItsPath() {
        // Torre: cup3, lid3 (ancho >= opener cup1 → debería quitarse)
        tower.pushCup("normal", 3);
        tower.pushLid("normal", 3);
        // lid3 tiene ancho >= cup1(opener), así que debe ser eliminada al insertar opener
        tower.pushCup("opener", 1);
        assertTrue(tower.ok());
        // La tapa 3 debería haber sido eliminada
        String[][] items = tower.stackingItems();
        boolean lid3Present = false;
        for (String[] item : items) {
            if ("lid".equals(item[0]) && "3".equals(item[1])) lid3Present = true;
        }
        assertFalse(lid3Present, "OpenerCup debio eliminar la tapa que le bloqueaba");
    }

    @Test
    public void openerCupShouldNotRemoveLidsSmallerThanItself() {
        // lid1 (ancho 70) < cup3-opener (ancho 130): NO debe eliminarse
        tower.pushCup("normal", 3);
        tower.pushLid("normal", 1);
        tower.pushCup("opener", 3);
        assertTrue(tower.ok());
        String[][] items = tower.stackingItems();
        boolean lid1Present = false;
        for (String[] item : items) {
            if ("lid".equals(item[0]) && "1".equals(item[1])) lid1Present = true;
        }
        assertTrue(lid1Present, "OpenerCup no debe eliminar tapas más pequeñas que él");
    }

    // ── HierarchicalCup ───────────────────────────────────────────────────────

    @Test
    public void hierarchicalCupShouldHaveCorrectSubtype() {
        tower.pushCup("hierarchical", 3);
        assertEquals("hierarchical", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void hierarchicalCupShouldDisplaceSmallerItems() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.pushCup("hierarchical", 3);
        assertTrue(tower.ok());
        // cup3 (ancho 130) debe estar antes que cup1 (ancho 70) y cup2 (ancho 100)
        String[][] items = tower.stackingItems();
        int posH = -1, posSmall = items.length;
        for (int i = 0; i < items.length; i++) {
            if ("cup".equals(items[i][0]) && "3".equals(items[i][1])) posH = i;
            if ("cup".equals(items[i][0]) && ("1".equals(items[i][1]) || "2".equals(items[i][1])))
                posSmall = Math.min(posSmall, i);
        }
        assertTrue(posH < posSmall, "HierarchicalCup debe estar antes que los ítems desplazados");
    }

    @Test
    public void hierarchicalCupAtBottomCannotBeRemoved() {
        tower.pushCup("hierarchical", 3);
        // No hay nada más grande → llega al fondo
        tower.popCup();
        assertFalse(tower.ok(), "HierarchicalCup que llegó al fondo no debe poder quitarse");
    }

    @Test
    public void hierarchicalCupNotAtBottomCanBeRemoved() {
        tower.pushCup("normal", 4); // cup4 más grande → cup3 no llega al fondo
        tower.pushCup("hierarchical", 3);
        tower.popCup();
        assertTrue(tower.ok());
    }

    // ── NormalLid ─────────────────────────────────────────────────────────────

    @Test
    public void normalLidShouldHaveCorrectSubtype() {
        tower.pushLid("normal", 1);
        assertEquals("normal", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void pushLidDefaultShouldBeNormal() {
        tower.pushLid(1);
        assertEquals("normal", tower.stackingItems()[0][2]);
    }

    // ── FearfulLid ────────────────────────────────────────────────────────────

    @Test
    public void fearfulLidShouldNotEnterIfCupAbsent() {
        // No hay cup1 en la torre
        tower.pushLid("fearful", 1);
        assertFalse(tower.ok(), "FearfulLid no debe entrar si su taza no está");
        assertEquals(0, tower.stackingItems().length);
    }

    @Test
    public void fearfulLidShouldEnterIfCupPresent() {
        tower.pushCup("normal", 1);
        tower.pushLid("fearful", 1);
        assertTrue(tower.ok());
        assertEquals(2, tower.stackingItems().length);
        assertEquals("fearful", tower.stackingItems()[1][2]);
    }

    @Test
    public void fearfulLidShouldNotLeaveWhenDirectlyAboveCup() {
        // cup1 → fearfulLid1 inmediatamente encima → no puede salir
        tower.pushCup("normal", 1);
        tower.pushLid("fearful", 1);
        tower.popLid();
        assertFalse(tower.ok(), "FearfulLid no debe salir cuando está directamente encima de su taza");
        assertEquals(2, tower.stackingItems().length);
    }

    @Test
    public void fearfulLidCanLeaveWhenNotDirectlyAboveCup() {
        // cup1 → cup2 → fearfulLid1: hay un ítem (cup2) entre lid1 y cup1
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.pushLid("fearful", 1);
        tower.popLid();
        assertTrue(tower.ok(), "FearfulLid puede salir cuando no está directamente encima de su taza");
        assertEquals(2, tower.stackingItems().length);
    }

    @Test
    public void fearfulLidCanLeaveWhenCupNotInTower() {
        // cup2 en torre, fearfulLid1 (taza 1 no está, pudo entrar en versión vieja
        // pero ahora: lid1 solo entra si cup1 está. Probamos lid de cup2.
        // cup2 → normalCup3 → fearfulLid2: hay cup3 en medio → puede salir
        tower.pushCup("normal", 2);
        tower.pushCup("normal", 3);
        tower.pushLid("fearful", 2);
        tower.popLid();
        assertTrue(tower.ok(), "FearfulLid puede salir si no está directamente encima de su taza");
    }

    // ── CrazyLid ──────────────────────────────────────────────────────────────

    @Test
    public void crazyLidShouldHaveCorrectSubtype() {
        tower.pushLid("crazy", 1);
        assertEquals("crazy", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void crazyLidShouldGoToBase() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.pushLid("crazy", 1);
        // La crazy lid debe estar en la posición 0
        assertEquals("lid",   tower.stackingItems()[0][0]);
        assertEquals("crazy", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    // ── StickyLid (tipo propuesto) ────────────────────────────────────────────

    @Test
    public void stickyLidShouldHaveCorrectSubtype() {
        tower.pushLid("sticky", 1);
        assertEquals("sticky", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void stickyLidCannotBePopped() {
        tower.pushLid("sticky", 1);
        tower.popLid();
        assertFalse(tower.ok(), "StickyLid no debe poder quitarse con popLid");
        assertEquals(1, tower.stackingItems().length);
    }

    @Test
    public void stickyLidCannotBeRemoved() {
        tower.pushLid("sticky", 1);
        tower.removeLid(0);
        assertFalse(tower.ok(), "StickyLid no debe poder quitarse con removeLid");
        assertEquals(1, tower.stackingItems().length);
    }

    // ── stackingItems con 3 columnas ──────────────────────────────────────────

    @Test
    public void stackingItemsShouldReturnThreeColumns() {
        tower.pushCup("opener", 2);
        String[][] items = tower.stackingItems();
        assertEquals(3, items[0].length);
        assertEquals("cup",    items[0][0]);
        assertEquals("2",      items[0][1]);
        assertEquals("opener", items[0][2]);
    }

    // ── Compatibilidad con lógica anterior ────────────────────────────────────

    @Test
    public void shouldReturnCorrectHeight() {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.pushLid(1);
        assertEquals(4, tower.height());
    }

    @Test
    public void shouldOrderTowerDescending() {
        tower.pushCup(1);
        tower.pushCup(3);
        tower.pushCup(2);
        tower.orderTower();
        assertTrue(tower.ok());
        assertEquals("3", tower.stackingItems()[0][1]);
        assertEquals("1", tower.stackingItems()[tower.stackingItems().length - 1][1]);
    }

    @Test
    public void shouldReturnLidedCups() {
        tower.pushCup(1);
        tower.pushLid(1);
        int[] lided = tower.lidedCups();
        assertEquals(1, lided.length);
        assertEquals(1, lided[0]);
    }

    @Test
    public void shouldNotCreateTowerWithZeroCups() {
        Tower t = new Tower(0);
        assertFalse(t.ok());
    }

    @Test
    public void solveShouldReturnImpossibleForInvalidInput() {
        assertEquals("impossible", TowerContest.solve(0, 5));
        assertEquals("impossible", TowerContest.solve(3, 0));
    }

    @Test
    public void solveShouldReturnZeroWhenAlreadyFits() {
        assertEquals("0", TowerContest.solve(3, 10));
    }
}
