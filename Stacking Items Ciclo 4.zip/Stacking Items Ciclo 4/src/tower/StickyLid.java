package tower;

/**
 * Tapa sticky: propuesta por nosotras
 * No puede quitarse una vez que está en la torre
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo 4
 */
public class StickyLid extends Lid {

    /**
     * Crea una tapa sticky.
     * El color de la tapa se ignora; siempre es naranja para distinguirla.
     */
    public StickyLid(int cupNumber, String color) {
        super(cupNumber, "orange");
    }

    @Override
    public String getSubtype() { 
        return "sticky"; 
    }

    /**
     * Altura visual ligeramente mayor para simular el grosor de la "cinta".
     */
    @Override
    public int getHeightPixels() {
        return LID_VISUAL_HEIGHT + 2;
    }
}
