package tower;

import shapes.Rectangle;

/**
 * Clase base abstracta para todos los tipos de tapa.
 * Subclases concretas: NormalLid, FearfulLid, CrazyLid, StickyLid.
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo 4
 */
public abstract class Lid implements Stackable {

    protected int     associatedCupNumber;
    protected String  lidColor;
    protected int     xPosition;
    protected int     yPosition;
    protected boolean showing;

    private Rectangle[] segments;
    private int[]       segW;      // ancho de cada segmento
    private int[]       segOffX;   // offset X relativo al origen de la tapa
    private int[]       segCurX;   // posición X absoluta actual
    private int[]       segCurY;   // posición Y absoluta actual

    public static final int LID_VISUAL_HEIGHT = Cup.WALL_THICKNESS;
    public static final int LID_HEIGHT_CM     = 1;

    /** 
     * Ancho por defecto de cada punto en la línea punteada. 
     */
    protected static final int DOT_W   = 6;
    
    /** 
     * Separación por defecto entre puntos. 
     */
    protected static final int DOT_GAP = 5;

    /**
     * Constructor base de tapa.
     */
    protected Lid(int cupNumber, String color) {
        this.associatedCupNumber = cupNumber;
        this.lidColor  = color;
        this.xPosition = 0;
        this.yPosition = 0;
        this.showing   = false;
        buildShapes();
    }

    /**
     * Hace la linea puntaeada.
     */
    protected int[][] buildSegments(int totalWidth) {
        int step = DOT_W + DOT_GAP;
        int num  = Math.max(1, totalWidth / step);
        int[][] segs = new int[num][2];
        for (int i = 0; i < num; i++) {
            segs[i][0] = i * step;   // offsetX
            segs[i][1] = DOT_W;      // ancho
        }
        return segs;
    }

    // Construcción visual
    
    private void buildShapes() {
        int w      = getWidthPixels();
        int h      = getHeightPixels();
        int[][] sg = buildSegments(w);

        segments = new Rectangle[sg.length];
        segW     = new int[sg.length];
        segOffX  = new int[sg.length];
        segCurX  = new int[sg.length];
        segCurY  = new int[sg.length];

        for (int i = 0; i < sg.length; i++) {
            segOffX[i] = sg[i][0];
            segW[i]    = sg[i][1];

            segments[i] = new Rectangle();
            segments[i].changeColor(lidColor);
            segments[i].changeSize(h, segW[i]);
            segments[i].moveHorizontal(-70);
            segments[i].moveVertical(-15);
            segCurX[i] = 0;
            segCurY[i] = 0;
        }
    }

    // Stackable 

    @Override public String getType()      { 
        return "lid"; 
    }
        
    @Override public int getItemNumber()   { 
        return associatedCupNumber; 
    }
    
    @Override public int getHeight()       {
        return LID_HEIGHT_CM;
    }
    
    @Override public int getWidthPixels()  { 
        return 40 + (associatedCupNumber * 30); 
    }
    
    @Override public int getHeightPixels() { 
        return LID_VISUAL_HEIGHT; 
    }

    @Override
    public void makeVisible() {
        if (showing) return;
        for (Rectangle s : segments) s.makeVisible();
        showing = true;
    }

    @Override
    public void makeInvisible() {
        for (Rectangle s : segments) s.makeInvisible();
        showing = false;
    }

    @Override public boolean isVisible() { return showing; }

    @Override
    public void moveTo(int x, int y) {
        for (int i = 0; i < segments.length; i++) {
            int tx = x + segOffX[i];
            segments[i].moveHorizontal(tx - segCurX[i]);
            segments[i].moveVertical(y  - segCurY[i]);
            segCurX[i] = tx;
            segCurY[i] = y;
        }
        this.xPosition = x;
        this.yPosition = y;
    }

    /** 
     * Retorna el color de la tapa. 
     */
    public String getColor() {
        return lidColor; 
    }
}