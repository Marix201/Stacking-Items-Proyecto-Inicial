package tower;

/**
 * Taza normal
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo 4
 */
public class NormalCup extends Cup {

    /**
     * Crea una taza normal.
     * @param number número de la taza (&gt;= 1)
     * @param color  color de la taza
     */
    public NormalCup(int number, String color) {
        super(number, color);
    }

    @Override
    public String getSubtype() { 
        return "normal"; 
    }
}
