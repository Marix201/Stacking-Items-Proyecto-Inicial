package tower;

/**
 * Tapa sticky: no puede quitarse una vez en la torre.
 * 
 * @author Hernandez - Tovar
 * @version 1 - Ciclo Final
 */
public class StickyLid extends Lid {

    public StickyLid(int cupNumber, String color) {
        super(cupNumber, "orange");
    }

    @Override
    public String getSubtype() { 
        return "sticky"; 
    }

    @Override
    public boolean isRemovable() { 
        return false; 
    }

    @Override
    public int getHeightPixels() {
        return LID_VISUAL_HEIGHT + 4;
    }

    @Override
    protected int[][] buildSegments(int totalWidth) {
        int segW = Math.max(6, (totalWidth - 12) / 3); // ancho de cada segmento
        int gap  = Math.max(4, (totalWidth - segW * 3) / 2); // espacio entre ellos

        int x1 = 0;
        int x2 = x1 + segW + gap;
        int x3 = x2 + segW + gap;

        return new int[][] {
            { x1, segW },
            { x2, segW },
            { x3, segW }
        };
    }
}