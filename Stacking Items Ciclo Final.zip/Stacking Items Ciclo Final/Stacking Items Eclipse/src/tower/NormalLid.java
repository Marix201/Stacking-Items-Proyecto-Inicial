package tower;

/**
 * Tapa normal: línea punteada uniforme (puntos pequeños iguales separados).
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo Final
 */
public class NormalLid extends Lid {

    public NormalLid(int cupNumber, String color) {
        super(cupNumber, color);
    }

    @Override
    public String getSubtype() { return "normal"; }

    // Usa buildSegments() por defecto de Lid: puntos uniformes pequeños
}