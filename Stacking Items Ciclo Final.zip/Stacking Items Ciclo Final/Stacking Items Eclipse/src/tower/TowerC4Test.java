package tower;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas de unidad para el Cierre.
 * Cubre todos los métodos públicos de Tower para maximizar el porcentaje
 * de cobertura reportado por JaCoCo / EclEmma en Eclipse.
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo Final
 */
public class TowerC4Test {

    private Tower tower;

    @BeforeEach
    public void setUp() {
        tower = new Tower(500, 200);
    }

    // Constructor Tower(int cups)
    
    @Test
    public void constructorWithCupsShouldCreateNormalCups() {
        Tower t = new Tower(3);
        assertTrue(t.ok());
        assertEquals(3, t.stackingItems().length);
        // El primero debe ser la taza mas grande (cup3)
        assertEquals("3", t.stackingItems()[0][1]);
        assertEquals("normal", t.stackingItems()[0][2]);
    }

    @Test
    public void shouldNotCreateTowerWithZeroCups() {
        Tower t = new Tower(0);
        assertFalse(t.ok());
    }

    @Test
    public void shouldNotCreateTowerWithNegativeCups() {
        Tower t = new Tower(-1);
        assertFalse(t.ok());
    }

    // pushCup sin tipo (normal)
    
    @Test
    public void pushCupDefaultShouldBeNormal() {
        tower.pushCup("normal", 1);  // ✅
        assertTrue(tower.ok());
        assertEquals("normal", tower.stackingItems()[0][2]);
    }

    // NormalCup
    
    @Test
    public void normalCupShouldHaveCorrectSubtype() {
        tower.pushCup("normal", 1);
        assertEquals("normal", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void pushCupShouldFailForNumberZero() {
        tower.pushCup("normal", 0);
        assertFalse(tower.ok());
        assertEquals(0, tower.stackingItems().length);
    }

    @Test
    public void pushCupShouldFailForNumberAboveMax() {
        tower.pushCup("normal", 16);
        assertFalse(tower.ok());
    }

    // OpenerCup
    
    @Test
    public void openerCupShouldHaveCorrectSubtype() {
        tower.pushCup("opener", 2);
        assertEquals("opener", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void openerCupShouldRemoveLidsBlockingItsPath() {
        tower.pushCup("normal", 3);
        tower.pushLid("normal", 3);
        tower.pushCup("opener", 1);
        assertTrue(tower.ok());
        for (String[] item : tower.stackingItems()) {
            assertFalse("lid".equals(item[0]) && "3".equals(item[1]),
                "OpenerCup debio eliminar la tapa bloqueante");
        }
    }

    @Test
    public void openerCupShouldNotRemoveLidsSmallerThanItself() {
        tower.pushCup("normal", 3);
        tower.pushLid("normal", 1);
        tower.pushCup("opener", 3);
        assertTrue(tower.ok());
        boolean lid1Present = false;
        for (String[] item : tower.stackingItems()) {
            if ("lid".equals(item[0]) && "1".equals(item[1])) lid1Present = true;
        }
        assertTrue(lid1Present, "OpenerCup no debe eliminar tapas mas pequenas que el");
    }

    // HierarchicalCup
    
    @Test
    public void hierarchicalCupShouldHaveCorrectSubtype() {
        tower.pushCup("hierarchical", 3);
        assertEquals("hierarchical", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void hierarchicalCupShouldDisplaceSmallerItems() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.pushCup("hierarchical", 3);
        assertTrue(tower.ok());
        String[][] items = tower.stackingItems();
        int posH = -1, posSmall = items.length;
        for (int i = 0; i < items.length; i++) {
            if ("cup".equals(items[i][0]) && "3".equals(items[i][1])) posH = i;
            if ("cup".equals(items[i][0]) && ("1".equals(items[i][1]) || "2".equals(items[i][1])))
                posSmall = Math.min(posSmall, i);
        }
        assertTrue(posH < posSmall, "HierarchicalCup debe estar antes que los desplazados");
    }

    @Test
    public void hierarchicalCupAtBottomCannotBeRemovedWithPop() {
        tower.pushCup("hierarchical", 3);
        String[][] items = tower.stackingItems();
        assertEquals(1, items.length);
        assertEquals("hierarchical", items[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void hierarchicalCupAtBottomCannotBeRemovedWithRemove() {
        tower.pushCup("hierarchical", 3);
        // Verificar que la taza hierarchical llegó al fondo
        String[][] items = tower.stackingItems();
        assertEquals(1, items.length);
        assertEquals("hierarchical", items[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void hierarchicalCupNotAtBottomCanBeRemoved() {
        tower.pushCup("normal", 4);
        tower.pushCup("hierarchical", 3);
        tower.popCup();
        assertTrue(tower.ok());
    }

    // popCup / removeCup (casos de error)
    
    @Test
    public void popCupShouldFailWhenNoCups() {
        tower.popCup();
        assertFalse(tower.ok());
    }

    @Test
    public void removeCupShouldFailForOutOfRangeIndex() {
        tower.pushCup("normal", 1);
        tower.removeCup(5);
        assertFalse(tower.ok());
    }

    @Test
    public void removeCupShouldFailForNegativeIndex() {
        tower.pushCup("normal", 1);
        tower.removeCup(-1);
        assertFalse(tower.ok());
    }

    @Test
    public void removeCupShouldSucceedForValidIndex() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.removeCup(0);
        assertTrue(tower.ok());
        assertEquals(1, tower.stackingItems().length);
    }

    // NormalLid

    @Test
    public void normalLidShouldHaveCorrectSubtype() {
        tower.pushLid("normal", 1);
        assertEquals("normal", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void pushLidDefaultShouldBeNormal() {
        tower.pushLid("normal", 1);
        assertTrue(tower.ok());
        assertEquals("normal", tower.stackingItems()[0][2]);
    }

    @Test
    public void pushLidShouldFailForNumberZero() {
        tower.pushLid("normal", 0);
        assertFalse(tower.ok());
    }

    // FearfulLid
    
    @Test
    public void fearfulLidShouldNotEnterIfCupAbsent() {
        tower.pushLid("fearful", 1);
        assertFalse(tower.ok());
        assertEquals(0, tower.stackingItems().length);
    }

    @Test
    public void fearfulLidShouldEnterIfCupPresent() {
        tower.pushCup("normal", 1);
        tower.pushLid("fearful", 1);
        assertTrue(tower.ok());
        assertEquals(2, tower.stackingItems().length);
        assertEquals("fearful", tower.stackingItems()[1][2]);
    }

    @Test
    public void fearfulLidShouldNotLeaveWhenDirectlyAboveCup() {
        tower.pushCup("normal", 1);
        tower.pushLid("fearful", 1);
        tower.popLid();
        assertFalse(tower.ok());
        assertEquals(2, tower.stackingItems().length);
    }

    @Test
    public void fearfulLidCanLeaveWhenNotDirectlyAboveCup() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.pushLid("fearful", 1);
        tower.popLid();
        assertTrue(tower.ok());
        assertEquals(2, tower.stackingItems().length);
    }

    @Test
    public void fearfulLidCanLeaveViaRemoveLid() {
        tower.pushCup("normal", 2);
        tower.pushCup("normal", 3);
        tower.pushLid("fearful", 2);
        tower.removeLid(0);
        assertTrue(tower.ok());
        assertEquals(2, tower.stackingItems().length);
    }

    // CrazyLid
    
    @Test
    public void crazyLidShouldHaveCorrectSubtype() {
        tower.pushLid("crazy", 1);
        assertEquals("crazy", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void crazyLidShouldGoToBase() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.pushLid("crazy", 1);
        assertEquals("lid",   tower.stackingItems()[0][0]);
        assertEquals("crazy", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    // StickyLid
    
    @Test
    public void stickyLidShouldHaveCorrectSubtype() {
        tower.pushLid("sticky", 1);
        assertEquals("sticky", tower.stackingItems()[0][2]);
        assertTrue(tower.ok());
    }

    @Test
    public void stickyLidCannotBePopped() {
        tower.pushLid("sticky", 1);
        tower.popLid();
        assertFalse(tower.ok());
        assertEquals(1, tower.stackingItems().length);
    }

    @Test
    public void stickyLidCannotBeRemoved() {
        tower.pushLid("sticky", 1);
        tower.removeLid(0);
        assertFalse(tower.ok());
        assertEquals(1, tower.stackingItems().length);
    }

    // popLid / removeLid (casos de error)
    
    @Test
    public void popLidShouldFailWhenNoLids() {
        tower.popLid();
        assertFalse(tower.ok());
    }

    @Test
    public void removeLidShouldFailForOutOfRangeIndex() {
        tower.pushLid("normal", 1);
        tower.removeLid(5);
        assertFalse(tower.ok());
    }

    @Test
    public void removeLidShouldSucceedForValidIndex() {
        tower.pushLid("normal", 1);
        tower.pushLid("normal", 2);
        tower.removeLid(0);
        assertTrue(tower.ok());
        assertEquals(1, tower.stackingItems().length);
    }

    // orderTower
    
    @Test
    public void shouldOrderTowerDescending() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 3);
        tower.pushCup("normal", 2);
        tower.orderTower();
        assertTrue(tower.ok());
        String[][] items = tower.stackingItems();
        assertEquals("3", items[0][1]);
        assertEquals("1", items[items.length - 1][1]);
    }

    @Test
    public void orderTowerShouldKeepStickyLidWithItsItem() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 3);
        tower.pushLid("sticky", 1);
        tower.orderTower();
        assertTrue(tower.ok());
        boolean stickyFound = false;
        for (String[] item : tower.stackingItems()) {
            if ("sticky".equals(item[2])) stickyFound = true;
        }
        assertTrue(stickyFound, "StickyLid debe permanecer tras orderTower");
    }

    // reverseTower
    
    @Test
    public void reverseTowerShouldInvertOrder() {
    	tower.pushCup("normal", 1);
    	tower.pushCup("normal", 2);
    	tower.pushCup("normal", 3);
    	String[][] before = tower.stackingItems();
    	tower.reverseTower();
    	assertTrue(tower.ok());
    	String[][] after = tower.stackingItems();
    	// Verificar que algo cambió o que el tamaño se mantiene
    	assertEquals(before.length, after.length);
    }

    @Test
    public void reverseTowerTwiceShouldRestoreOriginalOrder() {
        tower.pushCup("normal", 3);
        tower.pushCup("normal", 2);
        tower.pushCup("normal", 1);
        String[][] before = tower.stackingItems();
        tower.reverseTower();
        tower.reverseTower();
        String[][] after = tower.stackingItems();
        for (int i = 0; i < before.length; i++) {
            assertEquals(before[i][1], after[i][1]);
        }
    }

    // swap
    
    @Test
    public void swapShouldExchangeTwoItems() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.swap(new String[]{"cup", "1"}, new String[]{"cup", "2"});
        assertTrue(tower.ok());
        // Después del swap cup1 debe estar donde estaba cup2 y viceversa
        String[][] items = tower.stackingItems();
        assertEquals("2", items[0][1]);
        assertEquals("1", items[1][1]);
    }

    @Test
    public void swapShouldFailWhenItemNotFound() {
        tower.pushCup("normal", 1);
        tower.swap(new String[]{"cup", "1"}, new String[]{"cup", "99"});
        assertFalse(tower.ok());
    }

    // cover
    
    @Test
    public void coverShouldMarkCupWithLidAsLided() {
        tower.pushCup("normal", 1);
        tower.pushLid("normal", 1);
        tower.cover();
        assertTrue(tower.ok());
        int[] lided = tower.lidedCups();
        assertEquals(1, lided.length);
        assertEquals(1, lided[0]);
    }

    @Test
    public void coverShouldNotMarkCupWithoutLid() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.pushLid("normal", 1); // solo cup1 tiene tapa
        tower.cover();
        int[] lided = tower.lidedCups();
        assertEquals(1, lided.length);
    }

    // height
    
    @Test
    public void heightShouldBeZeroForEmptyTower() {
        assertEquals(0, tower.height());
    }

    @Test
    public void shouldReturnCorrectHeightWithLid() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.pushLid("normal", 1);
        assertEquals(4, tower.height());
    }

    @Test
    public void heightShouldGrowWithEachExternalCup() {
        tower.pushCup("normal", 1); // h=1
        assertEquals(1, tower.height());
        tower.pushCup("normal", 2); // h=1+2=3
        assertEquals(3, tower.height());
    }

    // lidedCups
    
    @Test
    public void shouldReturnLidedCups() {
        tower.pushCup("normal", 1);
        tower.pushLid("normal", 1);
        int[] lided = tower.lidedCups();
        assertEquals(1, lided.length);
        assertEquals(1, lided[0]);
    }

    @Test
    public void lidedCupsShouldBeEmptyWhenNoLids() {
        tower.pushCup("normal", 1);
        assertEquals(0, tower.lidedCups().length);
    }

    // stackingItems (estructura)
    
    @Test
    public void stackingItemsShouldReturnThreeColumns() {
        tower.pushCup("opener", 2);
        String[][] items = tower.stackingItems();
        assertEquals(3, items[0].length);
        assertEquals("cup",    items[0][0]);
        assertEquals("2",      items[0][1]);
        assertEquals("opener", items[0][2]);
    }

    @Test
    public void stackingItemsShouldBeEmptyForNewTower() {
        assertEquals(0, tower.stackingItems().length);
    }

    // swapToReduce
    
    @Test
    public void swapToReduceShouldReturnNullWhenNoSwapHelps() {
        // Una sola taza: no hay nada que intercambiar
        tower.pushCup("normal", 1);
        String[][] result = tower.swapToReduce();
        assertTrue(tower.ok());
        assertNull(result);
    }

    @Test
    public void swapToReduceShouldReturnPairWhenSwapHelps() {
        // cup2 arriba, cup1 abajo: intercambiarlos anida cup1 dentro de cup2
        tower.pushCup("normal", 2);
        tower.pushCup("normal", 1);
        String[][] result = tower.swapToReduce();
        assertTrue(tower.ok());
        // Puede encontrar un swap beneficioso
        if (result != null) {
            assertEquals(2, result.length);
        }
    }

    // TowerContest
    
    @Test
    public void solveShouldReturnImpossibleForInvalidInput() {
        assertEquals("impossible", TowerContest.solve(0, 5));
        assertEquals("impossible", TowerContest.solve(3, 0));
    }

    @Test
    public void solveShouldReturnZeroWhenAlreadyFits() {
        assertEquals("0", TowerContest.solve(3, 10));
    }

    @Test
    public void solveShouldReturnImpossibleWhenKEqualsN() {
        // n=1, h=1 → totalHeight=1, ya cabe → "0"
        assertEquals("0", TowerContest.solve(1, 1));
    }

    @Test
    public void solveShouldReturnPositiveSwapsWhenNeeded() {
        String result = TowerContest.solve(4, 10);
        assertNotEquals("impossible", result);
        int swaps = Integer.parseInt(result);
        assertTrue(swaps >= 0);
    }

    @Test
    public void contestSolveShouldBeConsistentWithHeight() {
        String result = TowerContest.solve(3, 4);
        assertNotEquals("impossible", result);
        assertTrue(Integer.parseInt(result) >= 0);
    }

    @Test
    public void contestSolveShouldBeImpossibleWithZeroHeight() {
        assertEquals("impossible", TowerContest.solve(4, 0));
    }

    // ── Decisión 3.1: ramas isDisplayed en métodos de Tower ──────────────────

    @Test
    public void pushCupVisibleShouldRedrawCup() {
        tower.makeVisible();
        tower.pushCup("normal", 1);
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void pushLidVisibleShouldRedrawLid() {
        tower.makeVisible();
        tower.pushCup("normal", 2);
        tower.pushLid("normal", 2);
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void popCupVisibleShouldRepositionAfterRemoval() {
        tower.pushCup("normal", 1);
        tower.makeVisible();
        tower.popCup();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void removeCupVisibleShouldRepositionAfterRemoval() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.makeVisible();
        tower.removeCup(0);
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void popLidVisibleShouldRepositionAfterRemoval() {
        tower.pushCup("normal", 1);
        tower.pushLid("normal", 1);
        tower.makeVisible();
        tower.popLid();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void removeLidVisibleShouldRepositionAfterRemoval() {
        tower.pushCup("normal", 1);
        tower.pushLid("normal", 1);
        tower.pushLid("normal", 2);
        tower.makeVisible();
        tower.removeLid(0);
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void pushHierarchicalCupVisibleShouldRedrawAll() {
        tower.pushCup("normal", 1);
        tower.makeVisible();
        tower.pushCup("hierarchical", 3);
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    // ── Decisión 3.2: ramas de anidamiento en repositionAll ──────────────────

    @Test
    public void repositionAllWithCupInsideOpenContainer() {
        // cup3 → cup1 (anidada dentro de cup3)
        tower.pushCup("normal", 3);
        tower.pushCup("normal", 1);
        tower.makeVisible();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void repositionAllWithLidInsideCoveredContainer() {
        // cup3 → tapa3 (cierra cup3) → cup1 dentro de cup3 tapado
        tower.pushCup("normal", 3);
        tower.pushLid("normal", 3);
        tower.pushCup("normal", 1);
        tower.makeVisible();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void repositionAllWithNestedCupsAndLids() {
        // Combinación con tapas de distintos tamaños y tazas anidadas
        tower.pushCup("normal", 5);
        tower.pushCup("normal", 3);
        tower.pushLid("normal", 3);
        tower.pushCup("normal", 1);
        tower.makeVisible();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void repositionAllCrazyLidAlwaysAtBase() {
        tower.pushCup("normal", 3);
        tower.pushCup("normal", 1);
        tower.pushLid("crazy", 1);
        tower.makeVisible();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    // ── Decisión 3.4: casos límite en pushCup y pushLid ──────────────────────

    @Test
    public void pushCupShouldFailForNumberBelowMin() {
        tower.pushCup("normal", 0);
        assertFalse(tower.ok());
        assertEquals(0, tower.stackingItems().length);
    }

    @Test
    public void pushCupShouldFailForNumber16() {
        tower.pushCup("normal", 16);
        assertFalse(tower.ok());
    }

    @Test
    public void pushLidShouldFailForNumberBelowMin() {
        tower.pushLid("normal", 0);
        assertFalse(tower.ok());
    }

    @Test
    public void pushLidShouldFailForNumberAboveMax() {
        tower.pushLid("normal", 16);
        assertFalse(tower.ok());
    }

    @Test
    public void pushCupShouldFailWhenTowerIsFull() {
        // Llenar el canvas con tazas grandes para forzar el rechazo por altura
        Tower smallTower = new Tower(50, 2);
        smallTower.pushCup("normal", 3);
        // Una taza de tamaño 3 (h=4 cm) ya excede 2 cm → debe fallar
        assertFalse(smallTower.ok());
    }

    @Test
    public void pushLidShouldFailWhenTowerIsFull() {
        // Torre muy pequeña: la tapa no cabe
        Tower smallTower = new Tower(50, 1);
        smallTower.pushCup("normal", 1); // ya ocupa 1 cm
        smallTower.pushLid("normal", 1); // no cabe: excede maxHeight
        assertFalse(smallTower.ok());
    }

    // ── Decisión 3.5: HierarchicalCup.setReachedBottom(false) ────────────────

    @Test
    public void hierarchicalCupNotAtBottomShouldBeRemovableByPop() {
        // cup4 ya ocupa el fondo; hierarchical cup3 no llega al fondo → puede quitarse
        tower.pushCup("normal", 4);
        tower.pushCup("hierarchical", 3);
        String[][] beforePop = tower.stackingItems();
        // La hierarchical NO llegó al fondo porque cup4 estaba antes
        tower.popCup();
        assertTrue(tower.ok(), "HierarchicalCup que no llego al fondo debe poder quitarse con popCup");
        assertEquals(beforePop.length - 1, tower.stackingItems().length);
    }

    @Test
    public void hierarchicalCupNotAtBottomShouldBeRemovableByIndex() {
        // cup5 ya ocupa el fondo; hierarchical cup2 no llega al fondo → puede quitarse por índice
        tower.pushCup("normal", 5);
        tower.pushCup("hierarchical", 2);
        tower.removeCup(1); // índice 1 entre tazas (cup2 es la segunda taza)
        assertTrue(tower.ok(), "HierarchicalCup que no llego al fondo debe poder quitarse con removeCup");
        assertEquals(1, tower.stackingItems().length);
    }
}