package tower;

/**
 * Tapa crazy: se ubica en la BASE de la torre en lugar de la cima.
 * 
 * @author Hernandez - Tovar
 * @version 1 - Ciclo Final
 */
public class CrazyLid extends Lid {

    public CrazyLid(int cupNumber, String color) {
        super(cupNumber, "magenta");
    }

    @Override
    public String getSubtype() { 
        return "crazy"; 
    }

    @Override
    public boolean goesToBase() { 
        return true; 
    }

    @Override
    public int getHeightPixels() {
        return LID_VISUAL_HEIGHT + 3;
    }
    
    @Override
    protected int[][] buildSegments(int totalWidth) {
        return new int[][] {
            { 0, totalWidth }   // un solo segmento de punta a punta
        };
    }
}