package tower;

import shapes.Rectangle;

/**
 * Clase base abstracta para todos los tipos de taza.
 * Subclases concretas: NormalCup, OpenerCup, HierarchicalCup.
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo Final
 */
public abstract class Cup implements Stackable {

    protected int     cupNumber;
    protected int     heightInCm;
    protected String  cupColor;
    protected int     posX;
    protected int     posY;
    protected boolean isShowing;
    protected boolean covered;

    // Piezas visuales
    private Rectangle leftWall;
    private Rectangle rightWall;
    private Rectangle bottomBar;

    private int leftCurX, leftCurY;
    private int rightCurX, rightCurY;
    private int botCurX,  botCurY;

    public static final int PIXELS_PER_CM  = 15;
    public static final int WALL_THICKNESS = 5;

    /**
     * Constructor base.
     * @param number número de la taza (&gt;= 1)
     * @param color  color de la taza
     */
    protected Cup(int number, String color) {
        this.cupNumber  = number;
        this.cupColor   = color;
        this.posX       = 0;
        this.posY       = 0;
        this.isShowing  = false;
        this.covered    = false;
        this.heightInCm = 1 << (number - 1); // 2^(n-1)
        buildShapes();
    }

    private void buildShapes() {
        int w     = getWidthPixels();
        int hPx   = getHeightPixels();
        int wallH = hPx - WALL_THICKNESS;

        leftWall = new Rectangle();
        leftWall.changeColor(cupColor);
        leftWall.changeSize(wallH, WALL_THICKNESS);
        leftWall.moveHorizontal(-70);
        leftWall.moveVertical(-15);
        leftCurX = 0; leftCurY = 0;

        rightWall = new Rectangle();
        rightWall.changeColor(cupColor);
        rightWall.changeSize(wallH, WALL_THICKNESS);
        rightWall.moveHorizontal(-70);
        rightWall.moveVertical(-15);
        rightCurX = 0; rightCurY = 0;

        bottomBar = new Rectangle();
        bottomBar.changeColor(cupColor);
        bottomBar.changeSize(WALL_THICKNESS, w);
        bottomBar.moveHorizontal(-70);
        bottomBar.moveVertical(-15);
        botCurX = 0; botCurY = 0;
    }

    // Stackable

    @Override public String getType()       { 
        return "cup"; 
    }
    
    @Override public int getItemNumber()    { 
        return cupNumber; 
    }
    
    @Override public int getHeight()        { 
        return heightInCm; 
    }
    
    @Override public int getWidthPixels()   { 
        return 40 + (cupNumber * 30); 
    }
    
    @Override public int getHeightPixels()  { 
        return 20 + (cupNumber * 25);
    }

    @Override
    public void makeVisible() {
        if (isShowing) return;
        leftWall.makeVisible();
        rightWall.makeVisible();
        bottomBar.makeVisible();
        isShowing = true;
    }

    @Override
    public void makeInvisible() {
        leftWall.makeInvisible();
        rightWall.makeInvisible();
        bottomBar.makeInvisible();
        isShowing = false;
    }

    @Override public boolean isVisible() { 
        return isShowing; 
    }

    @Override
    public void moveTo(int x, int y) {
        int w     = getWidthPixels();
        int hPx   = getHeightPixels();
        int wallH = hPx - WALL_THICKNESS;

        leftWall.moveHorizontal(x - leftCurX);
        leftWall.moveVertical(y - leftCurY);
        leftCurX = x; leftCurY = y;

        int rx = x + w - WALL_THICKNESS;
        rightWall.moveHorizontal(rx - rightCurX);
        rightWall.moveVertical(y - rightCurY);
        rightCurX = rx; rightCurY = y;

        int by = y + wallH;
        bottomBar.moveHorizontal(x - botCurX);
        bottomBar.moveVertical(by - botCurY);
        botCurX = x; botCurY = by;

        this.posX = x;
        this.posY = y;
    }

    @Override public void setCovered(boolean c) { 
        this.covered = c; 
    }
        
    @Override public boolean isCovered()        { 
        return covered; 
    }

    @Override
    public void setColor(String color) {
        this.cupColor = color;
        leftWall.changeColor(color);
        rightWall.changeColor(color);
        bottomBar.changeColor(color);
    }

    /** 
     * Retorna el color actual de la taza. 
     */
    public String getColor() {
        return cupColor; 
    }
}
