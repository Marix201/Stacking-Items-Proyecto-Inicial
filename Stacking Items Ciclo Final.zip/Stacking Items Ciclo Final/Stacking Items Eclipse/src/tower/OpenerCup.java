package tower;

import shapes.Rectangle;
import shapes.Triangle;

/**
 * Taza opener: al entrar a la torre elimina todas las tapas que le impiden el paso.
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo Final
 */
public class OpenerCup extends Cup {

    // Marcadores visuales: dos triángulos pequeños sobre las paredes
    private Triangle leftMark;
    private Triangle rightMark;
    private int lmCurX, lmCurY;
    private int rmCurX, rmCurY;

    private static final String MARK_COLOR = "white";
    private static final int    MARK_SIZE  = 6;

    /**
     * Crea una taza opener.
     * @param number número de la taza (&gt;= 1)
     * @param color  color base de la taza
     */
    public OpenerCup(int number, String color) {
        super(number, color);
        buildMarks();
    }

    private void buildMarks() {
        leftMark = new Triangle();
        leftMark.changeColor(MARK_COLOR);
        leftMark.changeSize(MARK_SIZE, WALL_THICKNESS);
        leftMark.moveHorizontal(-70);
        leftMark.moveVertical(-15);
        lmCurX = 0; lmCurY = 0;

        rightMark = new Triangle();
        rightMark.changeColor(MARK_COLOR);
        rightMark.changeSize(MARK_SIZE, WALL_THICKNESS);
        rightMark.moveHorizontal(-70);
        rightMark.moveVertical(-15);
        rmCurX = 0; rmCurY = 0;
    }

    @Override
    public String getSubtype() { 
        return "opener"; 
    }

    @Override
    public void makeVisible() {
        super.makeVisible();
        leftMark.makeVisible();
        rightMark.makeVisible();
    }

    @Override
    public void makeInvisible() {
        super.makeInvisible();
        leftMark.makeInvisible();
        rightMark.makeInvisible();
    }

    /**
     * Mueve la taza y sus marcadores visuales.
     */
    @Override
    public void moveTo(int x, int y) {
        super.moveTo(x, y);
        int midY = y + MARK_SIZE;

        leftMark.moveHorizontal(x - lmCurX);
        leftMark.moveVertical(midY - lmCurY);
        lmCurX = x; lmCurY = midY;

        int rx = x + getWidthPixels() - WALL_THICKNESS;
        rightMark.moveHorizontal(rx - rmCurX);
        rightMark.moveVertical(midY - rmCurY);
        rmCurX = rx; rmCurY = midY;
    }
}
