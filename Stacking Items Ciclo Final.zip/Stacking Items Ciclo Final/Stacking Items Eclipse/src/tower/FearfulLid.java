package tower;

/**
 * Tapa fearful: tiene dos reglas de comportamiento especiales que Tower debe respetar al ejecutar pushLid / popLid / removeLid
 * No entra si su taza compañera no está en la torre, no sale si está directamente encima de su taza compañera.
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo Final
 */
public class FearfulLid extends Lid {

    /** Ancho de cada uno de los dos bloques (px). */
    private static final int BLOCK_W    = 40;
    /** Hueco central entre los dos bloques (px). */
    private static final int CENTER_GAP = 4;

    /**
     * Crea una tapa fearful.
     * @param cupNumber número de la taza asociada
     * @param color     color de la tapa
     */
    public FearfulLid(int cupNumber, String color) {
        super(cupNumber, color);
    }

    @Override
    public String getSubtype() { 
        return "fearful"; 
    }

    @Override
    public boolean isFearful() { 
        return true; 
    }

    /**
     * Altura visual mayor para reforzar la distinción con la tapa normal.
     */
    @Override
    public int getHeightPixels() {
        return LID_VISUAL_HEIGHT + 4;
    }

    /**
     * Dos bloques rectangulares separados por un hueco en el centro.
     * El bloque izquierdo arranca en x=0 y el derecho justo después del hueco.
     */
    @Override
    protected int[][] buildSegments(int totalWidth) {
        // Bloque izquierdo: empieza en 0
        // Hueco central
        // Bloque derecho: empieza después del hueco
        int leftStart  = 0;
        int rightStart = totalWidth - BLOCK_W;

        // Asegurarse de que haya espacio real entre los bloques
        if (rightStart <= leftStart + BLOCK_W + CENTER_GAP) {
            rightStart = leftStart + BLOCK_W + CENTER_GAP;
        }

        return new int[][] {
            { leftStart,  BLOCK_W },   // bloque izquierdo
            { rightStart, BLOCK_W }    // bloque derecho
        };
    }
}