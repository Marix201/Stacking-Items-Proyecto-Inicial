package tower;

/**
 * Interfaz que deben implementar todos los elementos apilables en la torre.
 * Define el contrato común de posición, visibilidad y comportamiento.
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo Final
 */
public interface Stackable {

    /** 
     * Retorna la subcategoría del ítem: "cup" o "lid". 
     */
    String getType();

    /** 
     * Retorna el subtipo específico: "normal", "opener", "hierarchical", "fearful", "crazy", "sticky". 
     */
    String getSubtype();

    /** 
     * Retorna el número identificador del ítem. 
     */
    int getItemNumber();

    /** 
     * Altura lógica del ítem en cm.
     */
    int getHeight();

    /** 
     * Ancho visual en píxeles. 
     */
    int getWidthPixels();

    /** 
     * Altura visual en píxeles. 
     */
    int getHeightPixels();

    /**
     * Hace visible el ítem en el canvas. 
     */
    void makeVisible();

    /**
     * Hace invisible el ítem en el canvas. 
     */
    void makeInvisible();

    /**
     * Retorna true si el ítem está actualmente visible. 
     */
    boolean isVisible();

    /**
     * Mueve el ítem a la posición (x, y) en el canvas. 
     */
    void moveTo(int x, int y);

    /**
     * Marca el ítem como tapado o destapado (no-op para tapas).
     */
    default void setCovered(boolean covered) { /* no-op para Lid */ }

    /**
     * Retorna true si el ítem está marcado como tapado.
     */
    default boolean isCovered() { 
        return false; 
    }

    /**
     * Cambia el color visual del ítem (no-op para tapas). 
     */
    default void setColor(String color) { /* no-op para Lid */ }

    /**
     * Retorna true si el ítem puede ser removido de la torre.
     * Por defecto true; StickyLid lo sobreescribe retornando false.
     */
    default boolean isRemovable() { 
        return true; 
    }

    /**
     * Retorna true si el ítem es una tapa fearful.
     * Por defecto false; FearfulLid lo sobreescribe retornando true.
     */
    default boolean isFearful() { 
        return false; 
    }

    /**
     * Retorna true si el ítem debe ubicarse en la base de la torre al entrar.
     * Por defecto false; CrazyLid lo sobreescribe retornando true.
     */
    default boolean goesToBase() { 
        return false; 
    }

    /**
     * Retorna true si el ítem llegó al fondo y no puede quitarse.
     * Por defecto false; HierarchicalCup lo sobreescribe.
     */
    default boolean hasReachedBottom() { 
        return false; 
    }

    /**
     * Marca si el ítem llegó al fondo de la torre.
     * Solo relevante para HierarchicalCup.
     * @param value true si llegó al fondo
     */
    default void setReachedBottom(boolean value) { /* no-op por defecto */ }
}