package tower;

import javax.swing.JOptionPane;

/**
 * Resuelve y simula el problema de la maratón de programación 2025 (Problem J).
 * Solo usa tazas y tapas normales.
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo Final
 */
public class TowerContest {

    /**
     * Calcula el número mínimo de intercambios para que n tazas quepan en altura h.
     */
    public static String solve(int n, int h) {
        if (n < 1 || h < 1) return "impossible";
        long totalHeight = (1L << n) - 1;
        if (totalHeight <= h) return "0";
        long reduction = totalHeight - h;
        int k = 0;
        long sumSmall = 0;
        while (sumSmall < reduction) {
            if (k >= n) return "impossible";
            sumSmall += (1L << k);
            k++;
        }
        if (k >= n) return "impossible";
        int[] initial = new int[n];
        for (int i = 0; i < n; i++) initial[i] = i + 1;
        int[] target = new int[n];
        int pos = 0;
        for (int i = k + 1; i <= n; i++) target[pos++] = i;
        for (int i = 1; i <= k; i++)    target[pos++] = i;
        int[] rank = new int[n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                if (target[j] == initial[i]) { rank[i] = j; break; }
        return String.valueOf(countInversions(rank));
    }

    /**
     * Simula visualmente la solución: muestra estado inicial y final.
     */
    public static void simulate(int n, int h) {
        String result = solve(n, h);
        if ("impossible".equals(result)) {
            JOptionPane.showMessageDialog(null,
                "No es posible apilar " + n + " tazas en altura <= " + h + " cm.",
                "Simulación - Imposible", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        long totalHeight = (1L << n) - 1;
        if (totalHeight <= h) {
            Tower tower = new Tower(n);
            tower.makeVisible();
            JOptionPane.showMessageDialog(null,
                "La torre ya cabe en " + h + " cm. No se necesitan intercambios.\nAltura: " + tower.height() + " cm.",
                "Sin cambios", JOptionPane.INFORMATION_MESSAGE);
            tower.exit();
            return;
        }
        long reduction = totalHeight - h;
        int k = 0; long sumSmall = 0;
        while (sumSmall < reduction && k < n) { sumSmall += (1L << k); k++; }

        Tower towerInicial = new Tower(n);
        towerInicial.makeVisible();
        JOptionPane.showMessageDialog(null,
            "Configuración INICIAL: " + n + " tazas.\nAltura: " + towerInicial.height() +
            " cm.\nSolución: " + result + " intercambio(s).\n\nClic OK para ver configuración final.",
            "Estado inicial", JOptionPane.INFORMATION_MESSAGE);
        towerInicial.exit();

        Tower towerFinal = new Tower(500, 500);
        for (int i = n; i >= k + 1; i--) towerFinal.pushCup("normal", i);
        for (int i = k; i >= 1; i--)    towerFinal.pushCup("normal", i);
        towerFinal.makeVisible();
        JOptionPane.showMessageDialog(null,
            "Configuración FINAL tras " + result + " intercambio(s).\n" +
            "Las " + k + " taza(s) más pequeñas están anidadas.\n" +
            "Altura visible: " + (totalHeight - sumSmall) + " cm (<= " + h + " cm).",
            "Estado final", JOptionPane.INFORMATION_MESSAGE);
        towerFinal.exit();
    }

    private static long countInversions(int[] arr) {
        int[] temp = new int[arr.length];
        return mergeSort(arr, temp, 0, arr.length - 1);
    }

    private static long mergeSort(int[] arr, int[] temp, int left, int right) {
        if (left >= right) return 0;
        int mid = (left + right) / 2;
        long inv = mergeSort(arr, temp, left, mid) + mergeSort(arr, temp, mid + 1, right);
        return inv + merge(arr, temp, left, mid, right);
    }

    private static long merge(int[] arr, int[] temp, int left, int mid, int right) {
        for (int i = left; i <= right; i++) temp[i] = arr[i];
        int i = left, j = mid + 1, k = left;
        long inv = 0;
        while (i <= mid && j <= right) {
            if (temp[i] <= temp[j]) arr[k++] = temp[i++];
            else { inv += (mid - i + 1); arr[k++] = temp[j++]; }
        }
        while (i <= mid)  arr[k++] = temp[i++];
        while (j <= right) arr[k++] = temp[j++];
        return inv;
    }
}