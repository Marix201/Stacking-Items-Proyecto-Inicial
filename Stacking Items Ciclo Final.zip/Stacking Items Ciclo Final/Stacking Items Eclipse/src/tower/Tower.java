package tower;

import shapes.Rectangle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;
import javax.swing.JOptionPane;

/**
 * Modela la torre de tazas del simulador.
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo Final
 */
public class Tower {

    private ArrayList<Stackable> items;
    private int     towerWidth;
    private int     maxHeightCm;
    private boolean isDisplayed;
    private boolean lastOpOk;
    private ArrayList<Rectangle> scaleLines;

    private static final int BASE_Y   = 520;
    private static final int CENTER_X = 250;
    private static final int MAX_CUP  = 15; // taza 16 = 520px, se saldría del canvas de 500px

    // Constantes para la regla de escala
    private static final int SCALE_AXIS_X     = 32;
    private static final int SCALE_TICK_MAJOR = 14;
    private static final int SCALE_TICK_MINOR = 7;
    private static final int SCALE_OFFSET     = 15;

    // Constructores
    
    /**
     * Crea una torre vacía con dimensiones dadas.
     * @param width     ancho del canvas en px
     * @param maxHeight altura máxima en cm
     */
    public Tower(int width, int maxHeight) {
        this.towerWidth  = width;
        this.maxHeightCm = maxHeight;
        this.isDisplayed = false;
        this.lastOpOk    = true;
        this.items       = new ArrayList<Stackable>();
        this.scaleLines  = new ArrayList<Rectangle>();
    }

    /**
     * Crea una torre con n tazas normales apiladas de mayor a menor.
     * @param cups número de tazas (>= 1)
     */
    public Tower(int cups) {
        this(500, 200);
        if (cups < 1) { lastOpOk = false; return; }
        for (int i = cups; i >= 1; i--) {
            items.add(new NormalCup(i, colorForNumber(i)));
        }
        lastOpOk = true;
    }

    // Visibilidad 
    
    /** 
     * Hace visible la torre y dibuja la regla de escala. 
    */
    public void makeVisible() {
        if (isDisplayed) return;
        isDisplayed = true;
        repositionAll();
        for (Stackable item : items) item.makeVisible();
        buildScale();
    }

    /** 
     * Hace invisible la torre y oculta la regla de escala. 
       */
    public void makeInvisible() {
        if (!isDisplayed) return;
        for (Stackable item : items) item.makeInvisible();
        hideScale();
        isDisplayed = false;
    }

    // Gestión de tazas 
    
    /**
     * Agrega una taza del subtipo indicado.
     * Subtipos: "normal", "opener", "hierarchical".
     * @param type subtipo
     * @param i    número de taza (1..15)
     */
    public void pushCup(String type, int i) {
        if (i < 1 || i > MAX_CUP) {
            fail("Numero de taza debe ser entre 1 y " + MAX_CUP); return;
        }

        Cup cup = createCup(type, i);

        // Validar que cabe visualmente si va al exterior
        if (wouldBeExterior(cup.getWidthPixels()) &&
                visualHeightUsed() + cup.getHeightPixels() > BASE_Y) {
            fail("La taza " + i + " no cabe: se saldria del canvas"); return;
        }

        if ("opener".equals(type)) {
            ArrayList<Stackable> toRemove = new ArrayList<Stackable>();
            for (Stackable item : items) {
                if ("lid".equals(item.getType()) && item.getWidthPixels() >= cup.getWidthPixels()) {
                    toRemove.add(item);
                }
            }
            for (Stackable r : toRemove) { r.makeInvisible(); items.remove(r); }
        }

        if ("hierarchical".equals(type)) {
            ArrayList<Stackable> smaller = new ArrayList<Stackable>();
            ArrayList<Stackable> rest    = new ArrayList<Stackable>();
            for (Stackable item : items) {
                if (item.getWidthPixels() < cup.getWidthPixels()) smaller.add(item);
                else rest.add(item);
            }
            items = rest;
            items.add(cup);
            items.addAll(smaller);
            ((HierarchicalCup) cup).setReachedBottom(rest.isEmpty());
            if (isDisplayed) { cup.makeVisible(); repositionAll(); }
            lastOpOk = true;
            return;
        }

        items.add(cup);
        if (isDisplayed) { cup.makeVisible(); repositionAll(); }
        lastOpOk = true;
    }

    /**
     * Quita la última taza de la torre.
     * Falla si es hierarchical que llegó al fondo.
     */
    public void popCup() {
        int idx = lastIndexOfType("cup");
        if (idx < 0) { fail("No hay tazas"); return; }
        Stackable c = items.get(idx);
        if (c instanceof HierarchicalCup && ((HierarchicalCup) c).hasReachedBottom()) {
            fail("La taza hierarchical no puede quitarse: llego al fondo"); return;
        }
        items.remove(idx);
        c.makeInvisible();
        if (isDisplayed) repositionAll();
        lastOpOk = true;
    }

    /**
     * Elimina la taza en la posición dada (índice entre tazas, base 0).
     * @param index índice de la taza
     */
    public void removeCup(int index) {
        int cupCount = countByType("cup");
        if (index < 0 || index >= cupCount) {
            fail("Indice fuera de rango: " + index + ". Rango: 0.." + (cupCount - 1)); return;
        }
        int real = indexOfTypeByPosition("cup", index);
        Stackable c = items.get(real);
        if (c instanceof HierarchicalCup && ((HierarchicalCup) c).hasReachedBottom()) {
            fail("La taza hierarchical no puede quitarse: llego al fondo"); return;
        }
        items.remove(real);
        c.makeInvisible();
        if (isDisplayed) repositionAll();
        lastOpOk = true;
    }

    // Gestión de tapas 
    
    /**
     * Agrega una tapa del subtipo indicado.
     * Subtipos: "normal", "fearful", "crazy", "sticky".
     * @param type subtipo
     * @param i    número de tapa (1..15)
     */
    public void pushLid(String type, int i) {
        if (i < 1 || i > MAX_CUP) {
            fail("Numero de tapa debe ser entre 1 y " + MAX_CUP); return;
        }

        if ("fearful".equals(type) && findCupByNumber(i) == null) {
            fail("FearfulLid " + i + ": su taza no esta en la torre"); return;
        }

        Lid lid = createLid(type, i);

        // Validar que cabe visualmente si va al exterior
        if (wouldBeExterior(lid.getWidthPixels()) &&
                visualHeightUsed() + lid.getHeightPixels() > BASE_Y) {
            fail("La tapa " + i + " no cabe: se saldria del canvas"); return;
        }

        if ("crazy".equals(type)) {
            items.add(0, lid);
        } else {
            items.add(lid);
        }

        if (isDisplayed) { lid.makeVisible(); repositionAll(); }
        lastOpOk = true;
    }

    /**
     * Quita la última tapa de la torre.
     */
    public void popLid() {
        int idx = lastIndexOfType("lid");
        if (idx < 0) { fail("No hay tapas"); return; }
        Stackable l = items.get(idx);
        if (!canRemoveLid(l, idx)) return;
        items.remove(idx);
        l.makeInvisible();
        if (isDisplayed) repositionAll();
        lastOpOk = true;
    }

    /**
     * Elimina la tapa en la posición dada (índice entre tapas, base 0).
     * @param index índice de la tapa
     */
    public void removeLid(int index) {
        int lidCount = countByType("lid");
        if (index < 0 || index >= lidCount) {
            fail("Indice fuera de rango: " + index + ". Rango: 0.." + (lidCount - 1)); return;
        }
        int real = indexOfTypeByPosition("lid", index);
        Stackable l = items.get(real);
        if (!canRemoveLid(l, real)) return;
        items.remove(real);
        l.makeInvisible();
        if (isDisplayed) repositionAll();
        lastOpOk = true;
    }

    // Reorganización 

    /**
     * Ordena la torre de mayor a menor altura lógica.
     * Las StickyLid siguen al ítem que tenían debajo.
     */
    public void orderTower() {
        boolean vis = isDisplayed;
        if (vis) makeInvisible();
        ArrayList<ArrayList<Stackable>> blocks = buildBlocks();
        bubbleSortBlocks(blocks);
        rebuildFromBlocks(blocks);
        if (vis) makeVisible();
        lastOpOk = true;
    }

    /**
     * Invierte el orden de la torre.
     * Las StickyLid siguen al ítem que tenían debajo.
     */
    public void reverseTower() {
        boolean vis = isDisplayed;
        if (vis) makeInvisible();
        ArrayList<ArrayList<Stackable>> blocks = buildBlocks();
        Collections.reverse(blocks);
        rebuildFromBlocks(blocks);
        if (vis) makeVisible();
        lastOpOk = true;
    }

    /**
     * Intercambia dos objetos identificados por tipo y número.
     * @param o1 {tipo, número} del primer objeto
     * @param o2 {tipo, número} del segundo objeto
     */
    public void swap(String[] o1, String[] o2) {
        int idx1 = findItem(o1);
        int idx2 = findItem(o2);
        if (idx1 < 0 || idx2 < 0) { fail("Objeto no encontrado para swap"); return; }

        if (idx1 > idx2) {
            int tmp = idx1; idx1 = idx2; idx2 = tmp;
            String[] tmpa = o1; o1 = o2; o2 = tmpa;
        }

        boolean vis = isDisplayed;
        if (vis) makeInvisible();

        ArrayList<Stackable> block2 = extractWithStickyLids(idx2);
        ArrayList<Stackable> block1 = extractWithStickyLids(idx1);

        items.addAll(idx1, block2);
        int newIdx2 = idx2 - block1.size() + block2.size();
        if (newIdx2 < 0) newIdx2 = 0;
        if (newIdx2 > items.size()) newIdx2 = items.size();
        items.addAll(newIdx2, block1);

        if (vis) makeVisible();
        lastOpOk = true;
    }

    /**
     * Marca visualmente las tazas que tienen su tapa en la torre.
     */
    public void cover() {
        for (Stackable item : items) item.setCovered(false);
        for (Stackable item : items) {
            if ("lid".equals(item.getType())) {
                Stackable cup = findCupByNumber(item.getItemNumber());
                if (cup != null) cup.setCovered(true);
            }
        }
        if (isDisplayed) {
            for (Stackable item : items) {
                if ("cup".equals(item.getType())) {
                    item.setColor(item.isCovered()
                        ? "magenta"
                        : colorForNumber(item.getItemNumber()));
                }
            }
        }
        lastOpOk = true;
    }

    // Consultas 

    /**
     * Retorna la altura total de la torre en cm.
     */
    public int height() {
        Stack<int[]> containers = new Stack<int[]>();
        int towerHeightCm = 0;
        for (Stackable item : items) {
            int itemW = item.getWidthPixels();
            int itemH = item.getHeight();
            while (!containers.isEmpty() && itemW >= containers.peek()[0]) containers.pop();
            if ("cup".equals(item.getType())) {
                if (!containers.isEmpty() && containers.peek()[2] == 0) {
                    containers.peek()[1] = Math.max(containers.peek()[1], itemH);
                } else {
                    towerHeightCm += itemH;
                }
                containers.push(new int[]{ itemW, 0, 0 });
            } else {
                towerHeightCm += itemH;
                for (int[] c : containers) { if (c[0] == itemW) { c[2] = 1; break; } }
            }
        }
        return towerHeightCm;
    }

    /**
     * Retorna los números de las tazas que tienen su tapa en la torre.
     */
    public int[] lidedCups() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Stackable item : items) {
            if ("lid".equals(item.getType())) {
                int cn = item.getItemNumber();
                if (findCupByNumber(cn) != null) result.add(cn);
            }
        }
        int[] arr = new int[result.size()];
        for (int i = 0; i < arr.length; i++) arr[i] = result.get(i);
        return arr;
    }

    /**
     * Retorna todos los ítems como arreglo de [tipo, número, subtipo].
     */
    public String[][] stackingItems() {
        String[][] result = new String[items.size()][3];
        for (int i = 0; i < items.size(); i++) {
            result[i][0] = items.get(i).getType();
            result[i][1] = String.valueOf(items.get(i).getItemNumber());
            result[i][2] = items.get(i).getSubtype();
        }
        return result;
    }

    /**
     * Busca un intercambio que reduzca la altura total.
     * @return par de identificadores o null si ninguno reduce
     */
    public String[][] swapToReduce() {
        int currentHeight = height();
        for (int i = 0; i < items.size() - 1; i++) {
            for (int j = i + 1; j < items.size(); j++) {
                Stackable tmp = items.get(i);
                items.set(i, items.get(j));
                items.set(j, tmp);
                int newHeight = height();
                tmp = items.get(i);
                items.set(i, items.get(j));
                items.set(j, tmp);
                if (newHeight < currentHeight) {
                    lastOpOk = true;
                    return new String[][]{
                        itemIdentifier(items.get(i)),
                        itemIdentifier(items.get(j))
                    };
                }
            }
        }
        lastOpOk = true;
        return null;
    }

    /**
     * Cierra el simulador y limpia el canvas.
     */
    public void exit() {
        makeInvisible();
        items.clear();
        shapes.Canvas.getCanvas().clearAll();
        lastOpOk = true;
    }

    /**
     * Retorna true si la última operación fue exitosa.
     */
    public boolean ok() { return lastOpOk; }

    // Fábricas privadas 
    
    private Cup createCup(String type, int i) {
        String color = colorForNumber(i);
        switch (type) {
            case "opener":       return new OpenerCup(i, color);
            case "hierarchical": return new HierarchicalCup(i, color);
            default:             return new NormalCup(i, color);
        }
    }

    private Lid createLid(String type, int i) {
        String color = colorForNumber(i);
        switch (type) {
            case "fearful": return new FearfulLid(i, color);
            case "crazy":   return new CrazyLid(i, color);
            case "sticky":  return new StickyLid(i, color);
            default:        return new NormalLid(i, color);
        }
    }

    // Restricciones de tapas
    
    private boolean canRemoveLid(Stackable lid, int lidIdx) {
        if (lid instanceof StickyLid) {
            fail("StickyLid " + lid.getItemNumber() + ": no puede quitarse una vez en la torre");
            return false;
        }
        if (lid instanceof FearfulLid) {
            if (isDirectlyAboveCup(lidIdx, lid.getItemNumber())) {
                fail("FearfulLid " + lid.getItemNumber()
                        + ": no puede salir mientras este tapando directamente a su taza");
                return false;
            }
        }
        return true;
    }

    private boolean isDirectlyAboveCup(int lidIdx, int cupNumber) {
        for (int i = lidIdx - 1; i >= 0; i--) {
            Stackable below = items.get(i);
            if ("cup".equals(below.getType())) {
                return below.getItemNumber() == cupNumber;
            }
            break;
        }
        return false;
    }

    // Bloques para reordenamientos 
    
    private ArrayList<ArrayList<Stackable>> buildBlocks() {
        ArrayList<ArrayList<Stackable>> blocks = new ArrayList<ArrayList<Stackable>>();
        ArrayList<Stackable> currentBlock = null;

        for (Stackable item : items) {
            boolean isSticky = item instanceof StickyLid;

            if (isSticky) {
                // Se adhiere al bloque activo o crea uno si no hay ninguno
                if (currentBlock == null) {
                    currentBlock = new ArrayList<Stackable>();
                    blocks.add(currentBlock);
                }
                currentBlock.add(item);
                continue;
            }

            if ("cup".equals(item.getType())) {
                // Cada taza inicia su propio bloque
                currentBlock = new ArrayList<Stackable>();
                blocks.add(currentBlock);
                currentBlock.add(item);
            } else {
                // Tapa no-sticky: va al bloque de la taza anterior
                if (currentBlock == null) {
                    currentBlock = new ArrayList<Stackable>();
                    blocks.add(currentBlock);
                }
                currentBlock.add(item);
            }
        }
        return blocks;
    }

    private void bubbleSortBlocks(ArrayList<ArrayList<Stackable>> blocks) {
        for (int i = 0; i < blocks.size() - 1; i++) {
            for (int j = 0; j < blocks.size() - i - 1; j++) {
                if (blocks.get(j).get(0).getHeight() < blocks.get(j + 1).get(0).getHeight()) {
                    ArrayList<Stackable> tmp = blocks.get(j);
                    blocks.set(j, blocks.get(j + 1));
                    blocks.set(j + 1, tmp);
                }
            }
        }
    }

    private void rebuildFromBlocks(ArrayList<ArrayList<Stackable>> blocks) {
        items.clear();
        for (ArrayList<Stackable> block : blocks) items.addAll(block);
    }

    private ArrayList<Stackable> extractWithStickyLids(int idx) {
        ArrayList<Stackable> block = new ArrayList<Stackable>();
        if (idx < 0 || idx >= items.size()) return block;
        block.add(items.remove(idx));
        while (idx < items.size() && items.get(idx) instanceof StickyLid) {
            block.add(items.remove(idx));
        }
        return block;
    }

    // Reposicionamiento visual 

    private void repositionAll() {
        // Separar CrazyLids del resto — se posicionan al final siempre en el suelo
        ArrayList<Stackable> crazyLids = new ArrayList<Stackable>();
        ArrayList<Stackable> rest      = new ArrayList<Stackable>();
        for (Stackable item : items) {
            if (item instanceof CrazyLid) crazyLids.add(item);
            else rest.add(item);
        }

        // Posicionar todos los ítems normales
        Stack<int[]> containers = new Stack<int[]>();
        int towerTopY = BASE_Y;

        for (Stackable item : rest) {
            int itemW = item.getWidthPixels();
            int itemH = item.getHeightPixels();

            while (!containers.isEmpty() && itemW >= containers.peek()[0]) containers.pop();

            int placedTopY;

            if (!containers.isEmpty() && containers.peek()[3] == 1) {
                placedTopY = containers.peek()[2] - itemH;
                containers.peek()[2] = placedTopY;
                item.moveTo(CENTER_X - itemW / 2, placedTopY);
                if ("cup".equals(item.getType())) {
                    int innerFloor = placedTopY + itemH - Cup.WALL_THICKNESS;
                    containers.push(new int[]{ itemW, placedTopY, innerFloor, 1 });
                }
            } else if (!containers.isEmpty() && containers.peek()[3] == 0) {
                placedTopY = containers.peek()[2] - itemH;
                containers.peek()[2] = placedTopY;
                item.moveTo(CENTER_X - itemW / 2, placedTopY);
                if ("cup".equals(item.getType())) {
                    int innerFloor = placedTopY + itemH - Cup.WALL_THICKNESS;
                    containers.push(new int[]{ itemW, placedTopY, innerFloor, 0 });
                } else {
                    for (int[] c : containers) { if (c[0] == itemW) { c[3] = 1; break; } }
                    if (placedTopY < towerTopY) towerTopY = placedTopY;
                }
            } else {
                placedTopY = towerTopY - itemH;
                towerTopY  = placedTopY;
                item.moveTo(CENTER_X - itemW / 2, placedTopY);
                if ("cup".equals(item.getType())) {
                    int innerFloor = placedTopY + itemH - Cup.WALL_THICKNESS;
                    containers.push(new int[]{ itemW, placedTopY, innerFloor, 0 });
                } else {
                    for (int[] c : containers) { if (c[0] == itemW) { c[3] = 1; break; } }
                    if (placedTopY < towerTopY) towerTopY = placedTopY;
                }
            }
        }

        // Posicionar CrazyLids siempre en el suelo, una encima de la otra
        // Se dibujan al frente (makeVisible las pone en la capa superior del canvas)
        int crazyY = BASE_Y;
        for (Stackable lid : crazyLids) {
            crazyY -= lid.getHeightPixels();
            lid.moveTo(CENTER_X - lid.getWidthPixels() / 2, crazyY);
        }
    }

    // Validación de espacio visual

    /**
     * Retorna true si un ítem con el ancho dado quedaría en el exterior
     * (no contenido dentro de ninguna taza existente).
     */
    private boolean wouldBeExterior(int newItemWidth) {
        Stack<Integer> containerWidths = new Stack<Integer>();
        for (Stackable item : items) {
            int itemW = item.getWidthPixels();
            while (!containerWidths.isEmpty() && itemW >= containerWidths.peek()) {
                containerWidths.pop();
            }
            if ("cup".equals(item.getType())) {
                containerWidths.push(itemW);
            }
        }
        return containerWidths.isEmpty() || newItemWidth >= containerWidths.peek();
    }

    /**
     * Suma la altura visual en píxeles de los ítems exteriores de la torre.
     */
    private int visualHeightUsed() {
        Stack<Integer> containerWidths = new Stack<Integer>();
        int total = 0;
        for (Stackable item : items) {
            int itemW = item.getWidthPixels();
            while (!containerWidths.isEmpty() && itemW >= containerWidths.peek()) {
                containerWidths.pop();
            }
            if (containerWidths.isEmpty()) {
                total += item.getHeightPixels();
            }
            if ("cup".equals(item.getType())) {
                containerWidths.push(itemW);
            }
        }
        return total;
    }

    // Utilidades privadas

    private int findItem(String[] id) {
        if (id == null || id.length < 2) return -1;
        String type = id[0].trim();
        int num = Integer.parseInt(id[1].trim());
        for (int i = 0; i < items.size(); i++) {
            Stackable item = items.get(i);
            if (type.equals(item.getType()) && item.getItemNumber() == num) return i;
        }
        return -1;
    }

    private String[] itemIdentifier(Stackable item) {
        return new String[]{ item.getType(), String.valueOf(item.getItemNumber()) };
    }

    private Stackable findCupByNumber(int number) {
        for (Stackable item : items) {
            if ("cup".equals(item.getType()) && item.getItemNumber() == number) return item;
        }
        return null;
    }

    private int lastIndexOfType(String type) {
        for (int i = items.size() - 1; i >= 0; i--) {
            if (type.equals(items.get(i).getType())) return i;
        }
        return -1;
    }

    private int indexOfTypeByPosition(String type, int pos) {
        int count = 0;
        for (int i = 0; i < items.size(); i++) {
            if (type.equals(items.get(i).getType())) {
                if (count == pos) return i;
                count++;
            }
        }
        return -1;
    }

    private int countByType(String type) {
        int count = 0;
        for (Stackable item : items) { if (type.equals(item.getType())) count++; }
        return count;
    }

    private String colorForNumber(int num) {
        String[] colors = {"blue", "green", "red", "yellow", "orange", "magenta", "black", "cyan"};
        return colors[(num - 1) % colors.length];
    }

    // Regla de escala 

    private void buildScale() {
        if (!scaleLines.isEmpty()) return;
        int axisHeightPx = maxHeightCm * Cup.PIXELS_PER_CM;

        Rectangle axis = new Rectangle();
        axis.changeColor("black");
        axis.changeSize(axisHeightPx, 2);
        axis.moveHorizontal(SCALE_AXIS_X - 70);
        axis.moveVertical(BASE_Y - axisHeightPx - SCALE_OFFSET);
        axis.makeVisible();
        scaleLines.add(axis);

        for (int cm = 0; cm <= maxHeightCm; cm++) {
            int tickY   = BASE_Y - (cm * Cup.PIXELS_PER_CM) - 1;
            int tickLen = (cm % 5 == 0) ? SCALE_TICK_MAJOR : SCALE_TICK_MINOR;
            Rectangle tick = new Rectangle();
            tick.changeColor("black");
            tick.changeSize(2, tickLen);
            tick.moveHorizontal((SCALE_AXIS_X - tickLen) - 70);
            tick.moveVertical(tickY - SCALE_OFFSET);
            tick.makeVisible();
            scaleLines.add(tick);
        }
    }

    private void hideScale() {
        for (Rectangle line : scaleLines) line.makeInvisible();
        scaleLines.clear();
    }

    private void fail(String msg) {
        lastOpOk = false;
        if (isDisplayed) JOptionPane.showMessageDialog(null, "ERROR: " + msg);
    }
}