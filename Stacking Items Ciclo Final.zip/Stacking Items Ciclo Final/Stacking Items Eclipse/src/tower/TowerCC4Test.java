package tower;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas de casos comunes para el Ciclo 4 (TowerCC4Test).
 * Cubre escenarios de integración entre los distintos subtipos.
 *
 * @author Hernandez - Tovar
 * @version 1 - Ciclo Final
 */
public class TowerCC4Test {

    private Tower tower;

    @BeforeEach
    public void setUp() {
        tower = new Tower(500, 200);
    }

    // Interacción opener con múltiples tapas 

    @Test
    public void openerShouldRemoveAllBlockingLids() {
        tower.pushCup("normal", 3);
        tower.pushLid("normal", 3);
        tower.pushCup("normal", 2);
        tower.pushLid("normal", 2);
        // opener cup1 (ancho 70): lid2 (ancho 100) y lid3 (ancho 130) son >= 70 → se eliminan
        tower.pushCup("opener", 1);
        assertTrue(tower.ok());
        String[][] items = tower.stackingItems();
        for (String[] item : items) {
            if ("lid".equals(item[0])) {
                fail("OpenerCup debió eliminar todas las tapas bloqueantes, quedó: lid" + item[1]);
            }
        }
    }

    @Test
    public void openerShouldNotRemoveLidsSmallerThanItself() {
        tower.pushCup("normal", 1);
        tower.pushLid("normal", 1); // ancho 70
        tower.pushCup("opener", 3); // opener ancho 130; lid1 (70) < 130 → NO se elimina
        assertTrue(tower.ok());
        boolean lid1Found = false;
        for (String[] item : tower.stackingItems()) {
            if ("lid".equals(item[0]) && "1".equals(item[1])) lid1Found = true;
        }
        assertTrue(lid1Found);
    }

    // Interacción fearful con cover 

    @Test
    public void fearfulLidShouldNotExitWhenDirectlyAboveCup() {
        // cup2 → fearfulLid2 directamente encima → no puede salir
        tower.pushCup("normal", 2);
        tower.pushLid("fearful", 2);
        tower.popLid();
        assertFalse(tower.ok(), "FearfulLid directamente sobre su taza no puede salir");
        assertEquals(2, tower.stackingItems().length);
    }

    @Test
    public void fearfulLidShouldExitWhenAnotherItemIsBetween() {
        // cup2 → cup1 → fearfulLid2: cup1 está entre lid2 y cup2 → puede salir
        tower.pushCup("normal", 2);
        tower.pushCup("normal", 1);
        tower.pushLid("fearful", 2);
        tower.popLid();
        assertTrue(tower.ok(), "FearfulLid puede salir si no está directamente encima de su taza");
        assertEquals(2, tower.stackingItems().length);
    }

    // CrazyLid siempre va a la base 
    
    @Test
    public void multipleCrazyLidsShouldAllGoToBase() {
        tower.pushCup("normal", 3);
        tower.pushLid("crazy", 1);
        tower.pushLid("crazy", 2);
        // Las dos crazy lids deben estar al inicio, antes de cup3
        String[][] items = tower.stackingItems();
        assertEquals("lid",   items[0][0]);
        assertEquals("crazy", items[0][2]);
        assertEquals("lid",   items[1][0]);
        assertEquals("crazy", items[1][2]);
        assertEquals("cup",   items[2][0]);
    }

    // StickyLid permanece aunque se ordene

    @Test
    public void stickyLidShouldPersistAfterOrderTower() {
        tower.pushCup("normal", 3);
        tower.pushCup("normal", 1);
        tower.pushLid("sticky", 1);
        tower.orderTower();
        assertTrue(tower.ok());
        boolean stickyFound = false;
        for (String[] item : tower.stackingItems()) {
            if ("sticky".equals(item[2])) stickyFound = true;
        }
        assertTrue(stickyFound, "StickyLid debe permanecer en la torre después de orderTower");
    }

    // HierarchicalCup desplaza y queda fijo 

    @Test
    public void hierarchicalAtBottomShouldBlockBothPopAndRemove() {
        tower.pushCup("hierarchical", 4);
        String[][] items = tower.stackingItems();
        assertEquals(1, items.length);
        assertEquals("hierarchical", items[0][2]);
        assertTrue(tower.ok());
    }
    
    @Test
    public void hierarchicalNotAtBottomShouldBeRemovedByIndex() {
        tower.pushCup("normal", 4);
        tower.pushCup("hierarchical", 3);
        // cup4 está antes → cup3 no llega al fondo
        tower.removeCup(1); // índice 1 entre tazas
        assertTrue(tower.ok());
        assertEquals(1, tower.stackingItems().length);
    }

    // Mezcla de subtipos en una misma torre

    @Test
    public void mixedTypesShouldReturnCorrectHeight() {
        // cup3 (h=4), cup2 (h=2, anidada dentro de cup3), lid2
        tower.pushCup("normal", 3);
        tower.pushCup("hierarchical", 2);
        tower.pushLid("normal", 2);
        // cup2 está dentro de cup3 (más pequeña), lid2 la tapa
        // height: cup3 visible (4) + lid2 (1) = 5
        int h = tower.height();
        assertTrue(h > 0);
        assertTrue(tower.ok());
    }

    @Test
    public void mixedTypesShouldHaveThreeColumnsInStackingItems() {
        tower.pushCup("opener", 1);
        tower.pushCup("hierarchical", 2);
        tower.pushLid("fearful", 2);
        tower.pushLid("sticky", 1);
        String[][] items = tower.stackingItems();
        for (String[] item : items) {
            assertEquals(3, item.length, "Cada ítem debe tener 3 columnas: tipo, número, subtipo");
        }
    }

    // swapToReduce con tipos mixtos

    @Test
    public void swapToReduceShouldWorkWithMixedTypes() {
        tower.pushCup("normal", 3);
        tower.pushCup("opener", 1);
        String[][] result = tower.swapToReduce();
        assertTrue(tower.ok());
        // Puede o no existir un swap que reduzca; lo importante es que no lanza excepción
        if (result != null) {
            assertEquals(2, result.length);
        }
    }

    // TowerContest solo usa normales 

    @Test
    public void contestSolveShouldBeConsistentWithHeight() {
        // n=3, h=4: solve debe dar el número de intercambios para reducir altura
        String result = TowerContest.solve(3, 4);
        assertNotEquals("impossible", result);
        int swaps = Integer.parseInt(result);
        assertTrue(swaps >= 0);
    }

    @Test
    public void contestSolveShouldBeImpossibleWithZeroHeight() {
        assertEquals("impossible", TowerContest.solve(4, 0));
    }
    
    // Tests adicionales para la cobertura en Eclipse (Cup, Lid, OpenerCup, HierarchicalCup)

    @Test
    public void makeVisibleShouldShowTowerWithNormalCups() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.pushLid("normal", 1);
        tower.makeVisible();
        assertTrue(tower.ok());
        tower.makeInvisible();
        assertTrue(tower.ok());
    }

    @Test
    public void makeVisibleShouldShowOpenerCup() {
        tower.pushCup("opener", 2);
        tower.pushCup("opener", 1);
        tower.makeVisible();
        assertTrue(tower.ok());
        tower.makeInvisible();
        assertTrue(tower.ok());
    }

    @Test
    public void makeVisibleShouldShowHierarchicalCup() {
        tower.pushCup("normal", 1);
        tower.pushCup("hierarchical", 3);
        tower.makeVisible();
        assertTrue(tower.ok());
        tower.makeInvisible();
        assertTrue(tower.ok());
    }

    @Test
    public void makeVisibleShouldShowAllLidTypes() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.pushCup("normal", 3);
        tower.pushLid("normal", 3);
        tower.pushLid("fearful", 2);
        tower.pushLid("sticky", 1);
        tower.pushLid("crazy", 1);
        tower.makeVisible();
        assertTrue(tower.ok());
        tower.makeInvisible();
        assertTrue(tower.ok());
    }

    @Test
    public void coverShouldWorkWithVisibleTower() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.pushLid("normal", 1);
        tower.makeVisible();
        tower.cover();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void swapShouldWorkWithVisibleTower() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.makeVisible();
        tower.swap(new String[]{"cup", "1"}, new String[]{"cup", "2"});
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void orderTowerShouldWorkWithVisibleTower() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 3);
        tower.pushCup("normal", 2);
        tower.makeVisible();
        tower.orderTower();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void reverseTowerShouldWorkWithVisibleTower() {
        tower.pushCup("normal", 3);
        tower.pushCup("normal", 2);
        tower.pushCup("normal", 1);
        tower.makeVisible();
        tower.reverseTower();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void pushAndPopWithVisibleTower() {
        tower.makeVisible();
        tower.pushCup("normal", 1);
        tower.pushLid("normal", 1);
        tower.popLid();
        tower.popCup();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void exitShouldClearTower() {
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 2);
        tower.makeVisible();
        tower.exit();
        assertTrue(tower.ok());
    }

    @Test
    public void contestSimulateShouldRunWithValidInput() {
        // simulate con torre que ya cabe
        TowerContest.simulate(3, 10);
        // Si no lanza excepción, el test pasa
        assertTrue(true);
    }

    @Test
    public void contestSimulateShouldRunWhenReductionNeeded() {
        TowerContest.simulate(4, 10);
        assertTrue(true);
    }

    @Test
    public void contestSimulateShouldHandleImpossible() {
        TowerContest.simulate(3, 0);
        assertTrue(true);
    }

    // ── Decisión 3.2: lógica de anidamiento en repositionAll ─────────────────
    // Combinaciones con tazas de distintos tamaños y tapas para activar
    // cada rama del algoritmo de posicionamiento.

    @Test
    public void repositionAllItemGoesInsideOpenContainer() {
        // cup4 abierta; cup2 (más pequeña) queda anidada dentro de cup4
        tower.pushCup("normal", 4);
        tower.pushCup("normal", 2);
        tower.makeVisible();
        assertTrue(tower.ok());
        assertEquals(2, tower.stackingItems().length);
        tower.makeInvisible();
    }

    @Test
    public void repositionAllItemGoesInsideCoveredContainer() {
        // cup5 → lid5 (tapa cup5) → cup2 cae dentro del contenedor tapado
        tower.pushCup("normal", 5);
        tower.pushLid("normal", 5);
        tower.pushCup("normal", 2);
        tower.makeVisible();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void repositionAllItemGoesToExterior() {
        // cup1 → cup3: cup3 es más grande, queda en el exterior
        tower.pushCup("normal", 1);
        tower.pushCup("normal", 3);
        tower.makeVisible();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void repositionAllWithMultipleNestedLevels() {
        // cup6 → cup4 (dentro de cup6) → cup2 (dentro de cup4) → lid2, lid4
        tower.pushCup("normal", 6);
        tower.pushCup("normal", 4);
        tower.pushCup("normal", 2);
        tower.pushLid("normal", 4);
        tower.pushLid("normal", 2);
        tower.makeVisible();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }

    @Test
    public void repositionAllWithCrazyLidAndNestedCups() {
        // Mezcla: crazy va al suelo, tazas normales anidadas
        tower.pushCup("normal", 5);
        tower.pushCup("normal", 3);
        tower.pushLid("crazy", 2);
        tower.pushCup("normal", 1);
        tower.makeVisible();
        assertTrue(tower.ok());
        tower.makeInvisible();
    }
}