package shapes;

import java.awt.Polygon;

/**
 * Triángulo que puede manipularse y dibujarse en el canvas.
 * Extiende {@link Figure}, heredando posición, color, visibilidad y movimiento.
 *
 * @author Michael Kolling and David J. Barnes (Modified by Hernandez - Tovar)
 * @version 2 - Ciclo 4
 */
public class Triangle extends Figure {

    /** Número de vértices de un triángulo. */
    public static int VERTICES = 3;

    private int height;
    private int width;

    /**
     * Crea un triángulo en la posición y color por defecto.
     */
    public Triangle() {
        super(140, 15, "green");
        height = 30;
        width  = 40;
    }

    /**
     * Cambia las dimensiones del triángulo.
     * @param newHeight nueva altura en píxeles. Debe ser &gt;= 0.
     * @param newWidth  nuevo ancho en píxeles. Debe ser &gt;= 0.
     */
    public void changeSize(int newHeight, int newWidth) {
        erase();
        height = newHeight;
        width  = newWidth;
        draw();
    }

    // ── Figure ───────────────────────────────────────────────────────────────

    @Override
    protected void draw() {
        if (isVisible) {
            Canvas canvas = Canvas.getCanvas();
            int[] xpoints = { xPosition, xPosition + (width / 2), xPosition - (width / 2) };
            int[] ypoints = { yPosition, yPosition + height,       yPosition + height };
            canvas.draw(this, color, new Polygon(xpoints, ypoints, 3));
            canvas.wait(10);
        }
    }
}
