package shapes;

/**
 * Clase abstracta base para todas las figuras geométricas del simulador.
 * Centraliza los atributos y comportamientos comunes (posición, color,
 * visibilidad y movimiento) para que las subclases solo implementen
 * su dibujo específico.
 *
 * Subclases concretas: {@link Circle}, {@link Rectangle}, {@link Triangle}.
 *
 * @author Hernandez - Tovar
 * @version 2 - Ciclo 4
 */
public abstract class Figure {

    protected int    xPosition;
    protected int    yPosition;
    protected String color;
    protected boolean isVisible;

    /**
     * Inicializa la figura en la posición y color dados, invisible por defecto.
     * @param x     posición horizontal inicial (px)
     * @param y     posición vertical inicial (px)
     * @param color color inicial
     */
    protected Figure(int x, int y, String color) {
        this.xPosition = x;
        this.yPosition = y;
        this.color     = color;
        this.isVisible = false;
    }

    // ── Visibilidad ──────────────────────────────────────────────────────────

    /**
     * Hace visible la figura. Si ya era visible, no hace nada.
     */
    public void makeVisible() {
        isVisible = true;
        draw();
    }

    /**
     * Hace invisible la figura. Si ya era invisible, no hace nada.
     */
    public void makeInvisible() {
        erase();
        isVisible = false;
    }

    // ── Movimiento ───────────────────────────────────────────────────────────

    /**
     * Mueve la figura algunos píxeles a la derecha.
     */
    public void moveRight() {
        moveHorizontal(20);
    }

    /**
     * Mueve la figura algunos píxeles a la izquierda.
     */
    public void moveLeft() {
        moveHorizontal(-20);
    }

    /**
     * Mueve la figura algunos píxeles hacia arriba.
     */
    public void moveUp() {
        moveVertical(-20);
    }

    /**
     * Mueve la figura algunos píxeles hacia abajo.
     */
    public void moveDown() {
        moveVertical(20);
    }

    /**
     * Mueve la figura horizontalmente la distancia indicada.
     * @param distance distancia en píxeles (negativa = izquierda)
     */
    public void moveHorizontal(int distance) {
        erase();
        xPosition += distance;
        draw();
    }

    /**
     * Mueve la figura verticalmente la distancia indicada.
     * @param distance distancia en píxeles (negativa = arriba)
     */
    public void moveVertical(int distance) {
        erase();
        yPosition += distance;
        draw();
    }

    /**
     * Mueve la figura horizontalmente de forma lenta (píxel a píxel).
     * @param distance distancia total en píxeles
     */
    public void slowMoveHorizontal(int distance) {
        int delta = (distance < 0) ? -1 : 1;
        int steps = Math.abs(distance);
        for (int i = 0; i < steps; i++) {
            xPosition += delta;
            draw();
        }
    }

    /**
     * Mueve la figura verticalmente de forma lenta (píxel a píxel).
     * @param distance distancia total en píxeles
     */
    public void slowMoveVertical(int distance) {
        int delta = (distance < 0) ? -1 : 1;
        int steps = Math.abs(distance);
        for (int i = 0; i < steps; i++) {
            yPosition += delta;
            draw();
        }
    }

    // ── Color ────────────────────────────────────────────────────────────────

    /**
     * Cambia el color de la figura.
     * @param newColor nuevo color. Valores válidos: "red", "yellow", "blue",
     *                 "green", "magenta", "black", "orange", "cyan", "white".
     */
    public void changeColor(String newColor) {
        color = newColor;
        draw();
    }

    // ── Template methods ─────────────────────────────────────────────────────

    /**
     * Dibuja la figura en el canvas con sus especificaciones actuales.
     * Cada subclase implementa la geometría concreta.
     */
    protected abstract void draw();

    /**
     * Borra la figura del canvas.
     */
    protected void erase() {
        if (isVisible) {
            Canvas.getCanvas().erase(this);
        }
    }
}
