package shapes;

import java.awt.geom.Ellipse2D;

/**
 * Círculo que puede manipularse y dibujarse en el canvas.
 * Extiende {@link Figure}, heredando posición, color, visibilidad y movimiento.
 *
 * @author Michael Kolling and David J. Barnes (Modified by Hernandez - Tovar)
 * @version 2 - Ciclo 4
 */
public class Circle extends Figure {

    /** Constante matemática PI usada para cálculos de área. */
    public static final double PI = 3.1416;

    private int diameter;

    /**
     * Crea un círculo en la posición y color por defecto.
     */
    public Circle() {
        super(20, 15, "blue");
        diameter = 30;
    }

    /**
     * Cambia el diámetro del círculo.
     * @param newDiameter nuevo diámetro en píxeles. Debe ser &gt;= 0.
     */
    public void changeSize(int newDiameter) {
        erase();
        diameter = newDiameter;
        draw();
    }

    // ── Figure ───────────────────────────────────────────────────────────────

    @Override
    protected void draw() {
        if (isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                new Ellipse2D.Double(xPosition, yPosition, diameter, diameter));
            canvas.wait(10);
        }
    }
}
