package shapes;

/**
 * Rectángulo que puede manipularse y dibujarse en el canvas.
 * Extiende {@link Figure}, heredando posición, color, visibilidad y movimiento.
 *
 * @author Michael Kolling and David J. Barnes (Modified by Hernandez - Tovar)
 * @version 2 - Ciclo 4
 */
public class Rectangle extends Figure {

    /** Número de aristas de un rectángulo. */
    public static int EDGES = 4;

    private int height;
    private int width;

    /**
     * Crea un rectángulo en la posición y color por defecto.
     */
    public Rectangle() {
        super(70, 15, "magenta");
        height = 30;
        width  = 40;
    }

    /**
     * Cambia las dimensiones del rectángulo.
     * @param newHeight nueva altura en píxeles. Debe ser &gt;= 0.
     * @param newWidth  nuevo ancho en píxeles. Debe ser &gt;= 0.
     */
    public void changeSize(int newHeight, int newWidth) {
        erase();
        height = newHeight;
        width  = newWidth;
        draw();
    }

    // ── Figure ───────────────────────────────────────────────────────────────

    @Override
    protected void draw() {
        if (isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                new java.awt.Rectangle(xPosition, yPosition, width, height));
            canvas.wait(10);
        }
    }
}
