import shapes.*;

/**
 * Modela una taza en para la torre 
 *
 * @author Hernandez - Tovar
 * @version 2 - Ciclo 2
 */
public class Cup {
    private int cupNumber;
    private int heightInCm;
    private String cupColor;
    private int posX;
    private int posY;
    private boolean isShowing;
    private boolean covered;

    // partes visuales que  dan la forma de la taza
    private Rectangle leftWall;
    private Rectangle rightWall;
    private Rectangle bottomBar;

    // posición actual de cada rectángulo 
    private int leftCurX,  leftCurY;
    private int rightCurX, rightCurY;
    private int botCurX,   botCurY;

    public static final int PIXELS_PER_CM  = 15; // píxeles por centímetro lógico usado en la regla de la torre
    public static final int WALL_THICKNESS = 5; // grosor de paredes en px

    /**
     * Crea una taza con número y color dados.
     * @param number número de la taza (>= 1)
     * @param color  color de la taza
     */
    public Cup(int number, String color){
        this.cupNumber   = number;
        this.cupColor    = color;
        this.posX        = 0;
        this.posY        = 0;
        this.isShowing   = false;
        this.covered     = false;
        this.heightInCm  = calculateHeight(number);
        buildShapes(); // construye la forma correcta de la taza
    }

    // calcula la altura 2^(n-1) 
    private int calculateHeight(int n){
        int h = 1;
        for (int i = 0; i < n - 1; i++) h *= 2;
        return h;
    }

    /**
     * Crea la taza y la mueve a (0,0)
     * (el Rectangle de BlueJ nace en (70,15) por defecto, toca levarlo a (0,0))
     */
    private void buildShapes(){
        int w     = getCupWidthPixels();
        int hPx   = getHeightPixels();
        int wallH = hPx - WALL_THICKNESS; // altura de las paredes laterales

        leftWall = new Rectangle();
        leftWall.changeColor(cupColor);
        leftWall.changeSize(wallH, WALL_THICKNESS);
        leftWall.moveHorizontal(-70); // llevar al origen
        leftWall.moveVertical(-15);
        leftCurX = 0; leftCurY = 0;

        rightWall = new Rectangle();
        rightWall.changeColor(cupColor);
        rightWall.changeSize(wallH, WALL_THICKNESS);
        rightWall.moveHorizontal(-70);
        rightWall.moveVertical(-15);
        rightCurX = 0; rightCurY = 0;

        bottomBar = new Rectangle();
        bottomBar.changeColor(cupColor);
        bottomBar.changeSize(WALL_THICKNESS, w);
        bottomBar.moveHorizontal(-70);
        bottomBar.moveVertical(-15);
        botCurX = 0; botCurY = 0;
    }

    /**
     * Altura visual en píxeles
     * Separada de la altura lógica (2^(n-1) cm) para que todas las tazas sean visualmente perceptibles, incluso Cup1
     */
    public int getHeightPixels(){
        return 20 + (cupNumber * 25);
    }

    /**
     * Muestra la taza en pantalla.
     */
    public void makeVisible() {
        if (isShowing) return;
        leftWall.makeVisible();
        rightWall.makeVisible();
        bottomBar.makeVisible();
        isShowing = true;
    }

    /** 
     * Oculta la taza de la pantalla. 
       */
    public void makeInvisible(){
        if (!isShowing) return;
        leftWall.makeInvisible();
        rightWall.makeInvisible();
        bottomBar.makeInvisible();
        isShowing = false;
    }

    /**
     * Desplaza la taza a la posición (x, y)
     */
    private void moveShapesTo(int x, int y){
        int w     = getCupWidthPixels();
        int hPx   = getHeightPixels();
        int wallH = hPx - WALL_THICKNESS;

        // pared izquierda: esquina superior izquierda de la taza
        int lx = x, ly = y;
        leftWall.moveHorizontal(lx - leftCurX);
        leftWall.moveVertical(ly - leftCurY);
        leftCurX = lx; leftCurY = ly;

        // pared derecha: desplazada (ancho - grosor) a la derecha
        int rx = x + w - WALL_THICKNESS, ry = y;
        rightWall.moveHorizontal(rx - rightCurX);
        rightWall.moveVertical(ry - rightCurY);
        rightCurX = rx; rightCurY = ry;

        // fondo: debajo de las paredes
        int bx = x, by = y + wallH;
        bottomBar.moveHorizontal(bx - botCurX);
        bottomBar.moveVertical(by - botCurY);
        botCurX = bx; botCurY = by;
    }

    /**
     * Mueve la taza a (x, y) — actualiza siempre la posición interna
     */
    public void moveTo(int x, int y){
        moveShapesTo(x, y);
        this.posX = x;
        this.posY = y;
    }

    /**
     * Cambia el color de la taza.
     * cover: se usa para indicar visualmente que la taza está tapada.
     */
    public void setColor(String color){
        this.cupColor = color;
        leftWall.changeColor(color);
        rightWall.changeColor(color);
        bottomBar.changeColor(color);
    }

    public void setCovered(boolean c){
        this.covered = c; 
    }
    
    public boolean isCovered(){ 
        return covered; 
    }
    
    /** 
     * Ancho total de la taza en px: 40 + n*30 
       */
    public int     getCupWidthPixels(){ 
        return 40 + (cupNumber * 30);
    }
    
    /** 
     * Altura lógica en cm: 2^(n-1) 
     */
    public int getHeight(){ 
        return heightInCm; 
    }
    
    public int getIndex(){
        return cupNumber; 
    }
    
    public String  getColor(){
        return cupColor; 
    }
    
    public boolean isVisible(){
        return isShowing; 
    }
}
