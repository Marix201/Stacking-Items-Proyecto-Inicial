import shapes.*;
import java.util.ArrayList;

/**
 * Modela la torre de tazas del simulador 
 *
 * @author Hernandez - Tovar
 * @version 2 - Ciclo 2
 */
public class Tower {

    private ArrayList<Object> items;    // lista de Cup y Lid
    private int towerWidth;
    private int maxHeightCm;
    private boolean isDisplayed;
    private boolean lastOpOk;
    private ArrayList<Rectangle> scaleLines; // marcas de la regla lateral
    private static final int BASE_Y   = 520; // Y de la base de la torre en el canvas
    private static final int CENTER_X = 250; // X del centro horizontal del canvas


    /**
     * Constructor base
     */
    public Tower(int width, int maxHeight) {
        this.towerWidth  = width;
        this.maxHeightCm = maxHeight;
        this.isDisplayed = false;
        this.lastOpOk    = true;
        this.items       = new ArrayList<Object>();
        this.scaleLines  = new ArrayList<Rectangle>();
    }

    /**
     * Crea una torre con n tazas numeradas del 1 al n, sin tapas
     */
    public Tower(int cups) {
        this(500, 200);
        if (cups < 1) { lastOpOk = false; return; }
        for (int i = cups; i >= 1; i--) {
            items.add(new Cup(i, colorForNumber(i)));
        }
        lastOpOk = true;
    }

    /** 
     * Hace visible la torre, reposiciona todos los ítems y dibuja la regla
     */
    public void makeVisible() {
        if (isDisplayed) return;
        isDisplayed = true;
        repositionAll(); // calcula anidamiento
        for (Object item : items) {
            if (item instanceof Cup) ((Cup) item).makeVisible();
            else                    ((Lid) item).makeVisible();
        }
        buildScale(); //  dibuja la regla lateral
    }

    /** 
     * Hace invisible la torre y oculta la regla 
     */
    public void makeInvisible() {
        if (!isDisplayed) return;
        for (Object item : items) {
            if (item instanceof Cup) ((Cup) item).makeInvisible();
            else                    ((Lid) item).makeInvisible();
        }
        hideScale();
        isDisplayed = false;
    }

    // Gestión de las tazas 

    /** 
     * Agrega una taza a la cima de la torre
     */
    public void pushCup(int i) {
        if (i < 1) { fail("Numero de taza debe ser >= 1"); return; }
        Cup c = new Cup(i, colorForNumber(i));
        items.add(c);
        if (isDisplayed) { repositionAll(); c.makeVisible(); }
        lastOpOk = true;
    }

    /** 
     * Quita la última taza de la torre 
     */
    public void popCup() {
        int idx = lastIndexOf(Cup.class);
        if (idx < 0) { fail("No hay tazas"); return; }
        Cup c = (Cup) items.remove(idx);
        c.makeInvisible();
        if (isDisplayed) repositionAll();
        lastOpOk = true;
    }

    /** 
     * Elimina la taza en la posición dada
     */
    public void removeCup(int index) {
        int real = indexOfCupByPosition(index);
        if (real < 0) { fail("Indice de taza fuera de rango: " + index); return; }
        Cup c = (Cup) items.remove(real);
        c.makeInvisible();
        if (isDisplayed) repositionAll();
        lastOpOk = true;
    }

    // Gestión de las tapas 

    /** 
     * Agrega una tapa a la cima de la torre 
     */
    public void pushLid(int i) {
        if (i < 1) { fail("Numero debe ser >= 1"); return; }
        Lid l = new Lid(i, colorForNumber(i));
        items.add(l);
        if (isDisplayed) {
            repositionAll();
            l.makeVisible();
        }
        lastOpOk = true;
    }

    /** 
     * Quita la última tapa de la torre
     */
    public void popLid() {
        int idx = lastIndexOf(Lid.class);
        if (idx < 0) { fail("No hay tapas"); return; }
        Lid l = (Lid) items.remove(idx);
        l.makeInvisible();
        uncoverCupIfNeeded(l.getCupIndex());
        if (isDisplayed) repositionAll();
        lastOpOk = true;
    }

    /** 
     * Elimina la tapa en la posición dada
     */
    public void removeLid(int index) {
        int real = indexOfLidByPosition(index);
        if (real < 0) { fail("Indice de tapa fuera de rango: " + index); return; }
        Lid l = (Lid) items.remove(real);
        l.makeInvisible();
        uncoverCupIfNeeded(l.getCupIndex());
        if (isDisplayed) repositionAll();
        lastOpOk = true;
    }

    // Reorganización

    /**
     * Ordena la torre de mayor a menor altura
     * Cada tapa queda inmediatamente después de su taza
     */
    public void orderTower() {
        boolean vis = isDisplayed;
        if (vis) makeInvisible();
        bubbleSortItems(); // sort que respeta las tapas
        if (vis) makeVisible();
        lastOpOk = true;
    }

    /**
     * Invierte el orden de todos los ítems.
     * Corrige tapas que quedan antes de su taza tras la inversión.
     */
    public void reverseTower() {
        boolean vis = isDisplayed;
        if (vis) makeInvisible();
        java.util.Collections.reverse(items);
        // Corrige tapas: las mueve después de su taza
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i) instanceof Cup) {
                Cup cup = (Cup) items.get(i);
                for (int j = 0; j < i; j++) {
                    if (items.get(j) instanceof Lid &&
                        ((Lid) items.get(j)).getCupIndex() == cup.getIndex()) {
                        Lid lid = (Lid) items.remove(j);
                        items.add(i, lid);
                        break;
                    }
                }
            }
        }
        if (vis) makeVisible();
        lastOpOk = true;
    }

    /**
     * Intercambia dos objetos identificados por tipo, numero
     * Identificadores válidos: "cup","N" o "lid","N"
     */
    public void swap(String[] o1, String[] o2) {
        int idx1 = findItem(o1);
        int idx2 = findItem(o2);
        if (idx1 < 0 || idx2 < 0) { fail("Objeto no encontrado para swap"); return; }
        boolean vis = isDisplayed;
        if (vis) makeInvisible();
        Object temp = items.get(idx1);
        items.set(idx1, items.get(idx2));
        items.set(idx2, temp);
        if (vis) makeVisible();
        lastOpOk = true;
    }

    /**
     * Tapa las tazas que tienen su tapa en la torre
     */
    public void cover() {
        // desmarca todas
        for (Object item : items)
            if (item instanceof Cup) ((Cup) item).setCovered(false);
        // marca las que tienen tapa
        for (Object item : items) {
            if (item instanceof Lid) {
                Cup cup = findCupByNumber(((Lid) item).getCupIndex());
                if (cup != null) cup.setCovered(true);
            }
        }
        // actualiza colores visuales
        if (isDisplayed) {
            for (Object item : items) {
                if (item instanceof Cup) {
                    Cup cup = (Cup) item;
                    cup.setColor(cup.isCovered() ? "magenta" : colorForNumber(cup.getIndex()));
                }
            }
        }
        lastOpOk = true;
    }

    // Consultas

    /** 
     * altura total de la torre en cm
     */
    public int height() {
        int total = 0;
        for (Object item : items) {
            if (item instanceof Cup) total += ((Cup) item).getHeight();
            else                     total += Lid.LID_HEIGHT_CM;
        }
        return total;
    }

    /** 
     * números de tazas que tienen su tapa en la torre
     */
    public int[] lidedCups() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Object item : items) {
            if (item instanceof Lid) {
                int cn = ((Lid) item).getCupIndex();
                if (findCupByNumber(cn) != null) result.add(cn);
            }
        }
        int[] arr = new int[result.size()];
        for (int i = 0; i < arr.length; i++) arr[i] = result.get(i);
        return arr;
    }

    /** 
     * todos los ítems como {{tipo,numero},...}. Índice 0 = base. 
     */
    public String[][] stackingItems() {
        String[][] result = new String[items.size()][2];
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i) instanceof Cup) {
                result[i][0] = "cup";
                result[i][1] = String.valueOf(((Cup) items.get(i)).getIndex());
            } else {
                result[i][0] = "lid";
                result[i][1] = String.valueOf(((Lid) items.get(i)).getCupIndex());
            }
        }
        return result;
    }

    /**
     * Busca un intercambio que reduzca la altura total
     * Prueba todos los pares (i,j) con i<j y retorna el primero que mejora
     */
    public String[][] swapToReduce() {
        int currentHeight = height();
        for (int i = 0; i < items.size() - 1; i++) {
            for (int j = i + 1; j < items.size(); j++) {
                // simular swap
                Object temp = items.get(i);
                items.set(i, items.get(j));
                items.set(j, temp);
                int newHeight = height();
                // deshacer swap
                temp = items.get(i);
                items.set(i, items.get(j));
                items.set(j, temp);
                if (newHeight < currentHeight) {
                    lastOpOk = true;
                    return new String[][]{ itemIdentifier(items.get(i)), itemIdentifier(items.get(j)) };
                }
            }
        }
        lastOpOk = true;
        return null;
    }

    /** 
     * Cierra el simulador y limpia la torre. 
     */
    public void exit() {
        makeInvisible();
        items.clear();
        lastOpOk = true;
    }

    /** 
     * retorna true si la última operación fue exitosa. 
     */
    public boolean ok() { 
        return lastOpOk; 
    }

    // Métodos privados

    /**
     * Reposiciona todos los ítems usando una pila de contenedores.
     */
    private void repositionAll() {
        java.util.Stack<int[]> stack = new java.util.Stack<int[]>(); // {innerW, floorY}
        java.util.HashMap<Integer,Integer> cupTopY = new java.util.HashMap<Integer,Integer>();
        int currentTop = BASE_Y; // cima actual de la torre

        for (Object item : items) {
            if (item instanceof Cup) {
                Cup c  = (Cup) item;
                int cw = c.getCupWidthPixels();
                int ch = c.getHeightPixels();

                // desapila contenedores donde no quepa
                while (!stack.isEmpty() && cw > stack.peek()[0]) stack.pop();

                int topY;
                if (!stack.isEmpty()) {
                    // su base se apoya en el floorY del contenedor
                    topY = stack.peek()[1] - ch;
                    // currentTop NO cambia: la taza exterior ya fijó la altura de la torre
                } else {
                    // apila encima y actualiza la cima
                    topY = currentTop - ch;
                    currentTop = topY;
                }
                c.moveTo(CENTER_X - cw / 2, topY);
                cupTopY.put(c.getIndex(), topY);
                // Empujar esta taza como nuevo contenedor potencial
                stack.push(new int[]{ cw - 2 * Cup.WALL_THICKNESS,
                                      topY + ch - Cup.WALL_THICKNESS });

            } else {
                Lid l  = (Lid) item;
                int lw = 40 + (l.getCupIndex() * 30);
                int lh = Lid.LID_VISUAL_HEIGHT;
                // la tapa va encima del borde superior de su propia taza
                Integer myCupTopY = cupTopY.get(l.getCupIndex());
                int lidY = (myCupTopY != null) ? myCupTopY - lh : currentTop - lh;
                l.moveTo(CENTER_X - lw / 2, lidY);
                currentTop = lidY; // la tapa actualiza la cima
                stack.clear();     // la tapa cierra el contexto de anidamiento
            }
        }
    }

    /**
     * Ordena tazas de mayor a menor altura
     * Reconstruye la lista colocando cada tapa justo después de su taza
     */
    private void bubbleSortItems() {
        ArrayList<Cup> cups = new ArrayList<Cup>();
        ArrayList<Lid> lids = new ArrayList<Lid>();
        for (Object item : items) {
            if (item instanceof Cup) cups.add((Cup) item);
            else lids.add((Lid) item);
        }
        // burbuja descendente por altura lógica
        for (int i = 0; i < cups.size() - 1; i++) {
            for (int j = 0; j < cups.size() - i - 1; j++) {
                if (cups.get(j).getHeight() < cups.get(j + 1).getHeight()) {
                    Cup temp = cups.get(j);
                    cups.set(j, cups.get(j + 1));
                    cups.set(j + 1, temp);
                }
            }
        }
        //  taza + su tapa (si existe)
        items.clear();
        for (Cup cup : cups) {
            items.add(cup);
            for (Lid lid : lids) {
                if (lid.getCupIndex() == cup.getIndex()) {
                    items.add(lid);
                    break;
                }
            }
        }
        // Tapas sin taza en la torre al final
        for (Lid lid : lids) {
            if (findCupByNumber(lid.getCupIndex()) == null) items.add(lid);
        }
    }

    // Auxiliares

    private int findItem(String[] id) {
        if (id == null || id.length < 2) return -1;
        String type = id[0];
        int num = Integer.parseInt(id[1]);
        for (int i = 0; i < items.size(); i++) {
            Object item = items.get(i);
            if ("cup".equals(type) && item instanceof Cup && ((Cup) item).getIndex() == num) return i;
            if ("lid".equals(type) && item instanceof Lid && ((Lid) item).getCupIndex() == num) return i;
        }
        return -1;
    }

    private String[] itemIdentifier(Object item) {
        if (item instanceof Cup) return new String[]{"cup", String.valueOf(((Cup) item).getIndex())};
        return new String[]{"lid", String.valueOf(((Lid) item).getCupIndex())};
    }

    private Cup findCupByNumber(int number) {
        for (Object item : items) {
            if (item instanceof Cup && ((Cup) item).getIndex() == number) return (Cup) item;
        }
        return null;
    }

    private int lastIndexOf(Class<?> type) {
        for (int i = items.size() - 1; i >= 0; i--) {
            if (type.isInstance(items.get(i))) return i;
        }
        return -1;
    }

    private int indexOfCupByPosition(int pos) {
        int count = 0;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i) instanceof Cup) {
                if (count == pos) return i;
                count++;
            }
        }
        return -1;
    }

    private int indexOfLidByPosition(int pos) {
        int count = 0;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i) instanceof Lid) {
                if (count == pos) return i;
                count++;
            }
        }
        return -1;
    }

    private void uncoverCupIfNeeded(int cupNumber) {
        Cup c = findCupByNumber(cupNumber);
        if (c != null) {
            c.setCovered(false);
            if (isDisplayed) c.setColor(colorForNumber(c.getIndex()));
        }
    }

    private String colorForNumber(int num) {
        String[] colors = {"blue", "green", "red", "yellow", "orange", "magenta", "black", "white"};
        return colors[(num - 1) % colors.length];
    }

    /**
     * Construye la regla lateral
     * Muestra marcas cada 1 cm y marcas largas cada 5 cm
     */
    private void buildScale() {
        hideScale();
        if (!isDisplayed) return;
        int totalCm = height();
        if (totalCm == 0) return;

        int axisX = 32; // x del borde derecho de las marcas

        for (int cm = 0; cm <= totalCm; cm++) {
            int tickY    = BASE_Y - (cm * Cup.PIXELS_PER_CM) - 1;
            boolean major = (cm % 5 == 0);
            int tickLen  = major ? 12 : 6;

            Rectangle tick = new Rectangle();
            tick.changeColor("black");
            tick.changeSize(2, tickLen);
            tick.moveHorizontal((axisX - tickLen) - 70);
            tick.moveVertical(tickY - 15);
            tick.makeVisible();
            scaleLines.add(tick);
        }
    }

    /** 
     * Oculta y limpia la regla lateral. 
     */
    private void hideScale() {
        for (Rectangle line : scaleLines) line.makeInvisible();
        scaleLines.clear();
    }

    private void fail(String msg) {
        lastOpOk = false;
        if (isDisplayed) javax.swing.JOptionPane.showMessageDialog(null, "ERROR: " + msg);
    }
}
