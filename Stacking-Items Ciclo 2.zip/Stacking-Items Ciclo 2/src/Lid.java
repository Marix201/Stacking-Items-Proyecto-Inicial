import shapes.*;

/**
 * Modela la tapa de una taza 
 * 
 * @author Hernandez - Tovar
 * @version 2 - Ciclo 2
 */
public class Lid {
    private int    associatedCupNumber; // número de la taza a la que pertenece
    private String lidColor;
    private int    xPosition;
    private int    yPosition;
    private boolean showing;

    private Rectangle visualShape;

    // posición interna actual del rectangulo
    private int curX, curY;

    public static final int LID_VISUAL_HEIGHT = Cup.WALL_THICKNESS; // altura visual de la tapa en px
    public static final int LID_HEIGHT_CM     = 1; // altura lógica de la tapa en cm

    /**
     * Crea una tapa para la taza indicada
     */
    public Lid(int cupNumber, String color) {
        this.associatedCupNumber = cupNumber;
        this.lidColor  = color;
        this.xPosition = 0;
        this.yPosition = 0;
        this.showing   = false;
        buildShape(); // construye la forma de la tapa
    }

    /**
     * Crea el rectángulo de la tapa con el ancho de su taza y lo lleva al origen (0,0)      
     */
    private void buildShape() {
        int width = 40 + (associatedCupNumber * 30); // mismo ancho que Cup
        visualShape = new Rectangle();
        visualShape.changeColor(lidColor);
        visualShape.changeSize(LID_VISUAL_HEIGHT, width);
        // llevar desde posición por defecto (70,15) al origen
        visualShape.moveHorizontal(-70);
        visualShape.moveVertical(-15);
        curX = 0; curY = 0;
    }

    /** 
     * Hace visible la tapa. 
     */
    public void makeVisible() {
        if (showing) return;
        visualShape.makeVisible();
        showing = true;
    }

    /** 
     * Hace invisible la tapa. 
     */
    public void makeInvisible() {
        if (!showing) return;
        visualShape.makeInvisible();
        showing = false;
    }

    /**
     * Mueve la tapa a (x, y)
     */
    public void moveTo(int x, int y) {
        visualShape.moveHorizontal(x - curX);
        visualShape.moveVertical(y - curY);
        curX = x; curY = y;
        this.xPosition = x;
        this.yPosition = y;
    }

    public int getHeight(){ 
        return LID_HEIGHT_CM; 
    }
    
    public int getCupIndex(){ 
        return associatedCupNumber; 
    }
    
    public String  getColor(){ 
        return lidColor; 
    }
    
    public boolean isVisible(){
        return showing; 
    }
}
